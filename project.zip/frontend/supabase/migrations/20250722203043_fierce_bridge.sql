/*
  # Criação da tabela de usuários e estrutura inicial

  1. Novas Tabelas
    - `users`
      - `id` (uuid, chave primária)
      - `email` (text, único)
      - `password_hash` (text)
      - `created_at` (timestamp)
    - `categories`
      - `id` (uuid, chave primária)
      - `user_id` (uuid, referência para users)
      - `name` (text)
      - `created_at` (timestamp)
    - `expenses`
      - `id` (uuid, chave primária)
      - `user_id` (uuid, referência para users)
      - `name` (text)
      - `amount` (decimal)
      - `date` (date)
      - `category` (text)
      - `recurrence` (enum: none, weekly, monthly)
      - `notes` (text, opcional)
      - `created_at` (timestamp)

  2. Segurança
    - Habilitar RLS em todas as tabelas
    - Políticas de acesso baseadas em autenticação
    - Usuários só podem acessar seus próprios dados

  3. Índices
    - Índices em user_id para performance
    - Índices em date para consultas de período
*/

-- Tabela de usuários (será usada pelo Supabase Auth)
-- Nota: Esta tabela será criada automaticamente pelo Supabase Auth
-- Mantemos aqui apenas como referência da estrutura

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Tabela de despesas
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  amount decimal(10,2) NOT NULL CHECK (amount > 0),
  date date NOT NULL,
  category text NOT NULL,
  recurrence text CHECK (recurrence IN ('none', 'weekly', 'monthly')) DEFAULT 'none',
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Políticas para categorias
CREATE POLICY "Users can read own categories"
  ON categories
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own categories"
  ON categories
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own categories"
  ON categories
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own categories"
  ON categories
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Políticas para despesas
CREATE POLICY "Users can read own expenses"
  ON expenses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own expenses"
  ON expenses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own expenses"
  ON expenses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own expenses"
  ON expenses
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_categories_user_id ON categories(user_id);
CREATE INDEX IF NOT EXISTS idx_categories_name ON categories(user_id, name);

CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(user_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(user_id, category);
CREATE INDEX IF NOT EXISTS idx_expenses_recurrence ON expenses(user_id, recurrence) WHERE recurrence != 'none';

-- Inserir categorias padrão (função para ser executada após criação de usuário)
CREATE OR REPLACE FUNCTION insert_default_categories()
RETURNS trigger AS $$
BEGIN
  INSERT INTO categories (user_id, name) VALUES
    (NEW.id, 'Alimentação'),
    (NEW.id, 'Transporte'),
    (NEW.id, 'Lazer'),
    (NEW.id, 'Saúde'),
    (NEW.id, 'Educação'),
    (NEW.id, 'Casa'),
    (NEW.id, 'Roupas'),
    (NEW.id, 'Outros');
  RETURN NEW;
END;
$$ language plpgsql;

-- Trigger para inserir categorias padrão ao criar usuário
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE insert_default_categories();