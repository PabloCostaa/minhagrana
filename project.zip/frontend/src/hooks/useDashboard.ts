import { useState, useEffect, useMemo } from 'react';
import { startOfMonth, endOfMonth, startOfWeek, endOfWeek, format, eachDayOfInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Expense, DashboardStats } from '../types';
import { useExpenses } from './useExpenses';

const CATEGORY_COLORS = [
  '#10B981', '#3B82F6', '#8B5CF6', '#F59E0B', '#EF4444',
  '#06B6D4', '#84CC16', '#F97316', '#EC4899', '#6366F1'
];

export const useDashboard = (dateFilter?: Date) => {
  const { expenses } = useExpenses();
  const [stats, setStats] = useState<DashboardStats>({
    totalMonth: 0,
    totalWeek: 0,
    monthlyProjection: 0,
    expensesByCategory: [],
    dailyExpenses: [],
  });

  const filteredDate = dateFilter || new Date();

  const calculateStats = useMemo(() => {
    const monthStart = startOfMonth(filteredDate);
    const monthEnd = endOfMonth(filteredDate);
    const weekStart = startOfWeek(filteredDate);
    const weekEnd = endOfWeek(filteredDate);

    // Filter expenses for current month
    const monthExpenses = expenses.filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate >= monthStart && expenseDate <= monthEnd;
    });

    // Filter expenses for current week
    const weekExpenses = expenses.filter(expense => {
      const expenseDate = new Date(expense.date);
      return expenseDate >= weekStart && expenseDate <= weekEnd;
    });

    // Calculate totals
    const totalMonth = monthExpenses.reduce((sum, expense) => sum + expense.amount, 0);
    const totalWeek = weekExpenses.reduce((sum, expense) => sum + expense.amount, 0);

    // Calculate monthly projection based on recurring expenses
    const recurringExpenses = expenses.filter(expense => expense.recurrence !== 'none');
    const monthlyRecurring = recurringExpenses.reduce((sum, expense) => {
      if (expense.recurrence === 'monthly') return sum + expense.amount;
      if (expense.recurrence === 'weekly') return sum + (expense.amount * 4);
      return sum;
    }, 0);
    const monthlyProjection = totalMonth + monthlyRecurring;

    // Group by category
    const categoryTotals = monthExpenses.reduce((acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
      return acc;
    }, {} as Record<string, number>);

    const expensesByCategory = Object.entries(categoryTotals).map(([category, value], index) => ({
      category,
      value,
      color: CATEGORY_COLORS[index % CATEGORY_COLORS.length],
    }));

    // Daily expenses for line chart
    const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
    const dailyExpenses = daysInMonth.map(day => {
      const dayExpenses = monthExpenses.filter(expense => {
        const expenseDate = new Date(expense.date);
        return format(expenseDate, 'yyyy-MM-dd') === format(day, 'yyyy-MM-dd');
      });
      
      return {
        date: format(day, 'dd/MM', { locale: ptBR }),
        amount: dayExpenses.reduce((sum, expense) => sum + expense.amount, 0),
      };
    });

    return {
      totalMonth,
      totalWeek,
      monthlyProjection,
      expensesByCategory,
      dailyExpenses,
    };
  }, [expenses, filteredDate]);

  useEffect(() => {
    setStats(calculateStats);
  }, [calculateStats]);

  return stats;
};