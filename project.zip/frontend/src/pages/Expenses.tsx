import React from 'react';
import { ExpenseForm } from '../components/expenses/ExpenseForm';
import { ExpenseList } from '../components/expenses/ExpenseList';

export const Expenses: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Despesas</h1>
          <p className="text-gray-600 mt-1">Gerencie todas as suas despesas</p>
        </div>
      </div>

      <ExpenseList />
      <ExpenseForm />
    </div>
  );
};