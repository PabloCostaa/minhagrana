import React from 'react';
import { DollarSign, TrendingUp, Calendar, PieChart } from 'lucide-react';
import { useDashboard } from '../hooks/useDashboard';
import { StatsCard } from '../components/dashboard/StatsCard';
import { ExpenseChart } from '../components/dashboard/ExpenseChart';

export const Dashboard: React.FC = () => {
  const stats = useDashboard();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Acompanhe suas despesas em tempo real</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total do Mês"
          value={formatCurrency(stats.totalMonth)}
          icon={DollarSign}
          color="bg-gradient-to-br from-green-500 to-green-600"
        />
        <StatsCard
          title="Total da Semana"
          value={formatCurrency(stats.totalWeek)}
          icon={Calendar}
          color="bg-gradient-to-br from-blue-500 to-blue-600"
        />
        <StatsCard
          title="Projeção Mensal"
          value={formatCurrency(stats.monthlyProjection)}
          icon={TrendingUp}
          color="bg-gradient-to-br from-purple-500 to-purple-600"
        />
        <StatsCard
          title="Categorias Ativas"
          value={stats.expensesByCategory.length.toString()}
          icon={PieChart}
          color="bg-gradient-to-br from-orange-500 to-orange-600"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {stats.expensesByCategory.length > 0 && (
          <ExpenseChart
            data={stats.expensesByCategory}
            type="pie"
            title="Despesas por Categoria"
          />
        )}
        
        {stats.dailyExpenses.length > 0 && (
          <ExpenseChart
            data={stats.dailyExpenses}
            type="line"
            title="Evolução Diária das Despesas"
          />
        )}
      </div>

      {stats.expensesByCategory.length === 0 && stats.dailyExpenses.length === 0 && (
        <div className="text-center py-12">
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <PieChart className="text-gray-400" size={32} />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma despesa encontrada</h3>
          <p className="text-gray-600">Adicione algumas despesas para visualizar os gráficos</p>
        </div>
      )}
    </div>
  );
};