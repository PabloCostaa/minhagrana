export interface User {
  id: string;
  email: string;
  created_at: string;
}

export interface Category {
  id: string;
  user_id: string;
  name: string;
  created_at: string;
}

export interface Expense {
  id: string;
  user_id: string;
  name: string;
  amount: number;
  date: string;
  category: string;
  recurrence: 'none' | 'weekly' | 'monthly';
  notes: string | null;
  created_at: string;
}

export interface ExpenseFormData {
  name: string;
  amount: number;
  date: string;
  category: string;
  recurrence: 'none' | 'weekly' | 'monthly';
  notes: string;
}

export interface CategoryFormData {
  name: string;
}

export interface AuthFormData {
  email: string;
  password: string;
}

export interface DashboardStats {
  totalMonth: number;
  totalWeek: number;
  monthlyProjection: number;
  expensesByCategory: Array<{ category: string; value: number; color: string }>;
  dailyExpenses: Array<{ date: string; amount: number }>;
}