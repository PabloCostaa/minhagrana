import React, { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Edit3, Trash2, Calendar, Tag } from 'lucide-react';
import { useExpenses } from '../../hooks/useExpenses';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Toast } from '../ui/Toast';
import { Expense } from '../../types';

export const ExpenseList: React.FC = () => {
  const { expenses, deleteExpense } = useExpenses();
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info'; isVisible: boolean }>({
    message: '',
    type: 'info',
    isVisible: false,
  });

  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type, isVisible: true });
  };

  const hideToast = () => {
    setToast(prev => ({ ...prev, isVisible: false }));
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta despesa?')) {
      try {
        await deleteExpense(id);
        showToast('Despesa excluída com sucesso!', 'success');
      } catch (error) {
        showToast('Erro ao excluir despesa', 'error');
      }
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const getRecurrenceText = (recurrence: string) => {
    switch (recurrence) {
      case 'weekly':
        return 'Semanal';
      case 'monthly':
        return 'Mensal';
      default:
        return 'Única';
    }
  };

  const getRecurrenceColor = (recurrence: string) => {
    switch (recurrence) {
      case 'weekly':
        return 'bg-blue-100 text-blue-800';
      case 'monthly':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (expenses.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
          <Calendar className="text-gray-400" size={32} />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhuma despesa encontrada</h3>
        <p className="text-gray-600">Adicione sua primeira despesa clicando no botão +</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {expenses.map((expense) => (
          <Card key={expense.id} className="p-4 hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-center justify-between">
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-gray-900">{expense.name}</h3>
                  <span className="text-lg font-bold text-red-600">
                    {formatCurrency(expense.amount)}
                  </span>
                </div>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Calendar size={14} />
                    <span>{format(new Date(expense.date), 'dd/MM/yyyy', { locale: ptBR })}</span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Tag size={14} />
                    <span>{expense.category}</span>
                  </div>
                  
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRecurrenceColor(expense.recurrence)}`}>
                    {getRecurrenceText(expense.recurrence)}
                  </span>
                </div>
                
                {expense.notes && (
                  <p className="text-sm text-gray-600 mt-2">{expense.notes}</p>
                )}
              </div>
              
              <div className="flex items-center space-x-2 ml-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    // TODO: Implement edit functionality
                    showToast('Função de edição em desenvolvimento', 'info');
                  }}
                >
                  <Edit3 size={16} />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDelete(expense.id)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <Trash2 size={16} />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  );
};