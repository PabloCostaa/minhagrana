import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { format } from 'date-fns';
import { Plus } from 'lucide-react';
import { useExpenses } from '../../hooks/useExpenses';
import { useCategories } from '../../hooks/useCategories';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { Toast } from '../ui/Toast';
import { ExpenseFormData } from '../../types';

const schema = yup.object({
  name: yup.string().required('Nome é obrigatório'),
  amount: yup.number().positive('Valor deve ser positivo').required('Valor é obrigatório'),
  date: yup.string().required('Data é obrigatória'),
  category: yup.string().required('Categoria é obrigatória'),
  recurrence: yup.string().oneOf(['none', 'weekly', 'monthly']).required(),
  notes: yup.string(),
});

export const ExpenseForm: React.FC = () => {
  const { addExpense } = useExpenses();
  const { categories, addCategory } = useCategories();
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [showNewCategory, setShowNewCategory] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info'; isVisible: boolean }>({
    message: '',
    type: 'info',
    isVisible: false,
  });

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm<ExpenseFormData>({
    resolver: yupResolver(schema),
    defaultValues: {
      date: format(new Date(), 'yyyy-MM-dd'),
      recurrence: 'none',
      notes: '',
    },
  });

  const showToast = (message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type, isVisible: true });
  };

  const hideToast = () => {
    setToast(prev => ({ ...prev, isVisible: false }));
  };

  const handleAddCategory = async () => {
    if (!newCategory.trim()) return;

    try {
      await addCategory(newCategory.trim());
      setValue('category', newCategory.trim());
      setNewCategory('');
      setShowNewCategory(false);
      showToast('Categoria criada com sucesso!', 'success');
    } catch (error) {
      showToast('Erro ao criar categoria', 'error');
    }
  };

  const onSubmit = async (data: ExpenseFormData) => {
    try {
      setLoading(true);
      await addExpense({
        name: data.name,
        amount: data.amount,
        date: data.date,
        category: data.category,
        recurrence: data.recurrence,
        notes: data.notes || null,
      });
      
      reset();
      setIsOpen(false);
      showToast('Despesa adicionada com sucesso!', 'success');
    } catch (error) {
      showToast('Erro ao adicionar despesa', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button onClick={() => setIsOpen(true)} className="fixed bottom-6 right-6 z-40 rounded-full shadow-xl">
        <Plus size={24} />
      </Button>

      <Modal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title="Nova Despesa"
      >
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input
            {...register('name')}
            label="Nome da despesa"
            placeholder="Ex: Supermercado"
            error={errors.name?.message}
          />

          <Input
            {...register('amount', { valueAsNumber: true })}
            type="number"
            step="0.01"
            label="Valor"
            placeholder="0,00"
            error={errors.amount?.message}
          />

          <Input
            {...register('date')}
            type="date"
            label="Data"
            error={errors.date?.message}
          />

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Categoria</label>
            <div className="space-y-2">
              <select
                {...register('category')}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">Selecione uma categoria</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.name}>
                    {category.name}
                  </option>
                ))}
              </select>
              {errors.category && (
                <p className="text-sm text-red-600">{errors.category.message}</p>
              )}
              
              {!showNewCategory ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowNewCategory(true)}
                >
                  + Nova categoria
                </Button>
              ) : (
                <div className="flex space-x-2">
                  <Input
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    placeholder="Nome da categoria"
                    className="flex-1"
                  />
                  <Button type="button" size="sm" onClick={handleAddCategory}>
                    Adicionar
                  </Button>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    onClick={() => {
                      setShowNewCategory(false);
                      setNewCategory('');
                    }}
                  >
                    Cancelar
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Recorrência</label>
            <select
              {...register('recurrence')}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            >
              <option value="none">Despesa única</option>
              <option value="weekly">Recorrente semanal</option>
              <option value="monthly">Recorrente mensal</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Observações</label>
            <textarea
              {...register('notes')}
              placeholder="Observações opcionais"
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
            />
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              type="button"
              variant="secondary"
              onClick={() => setIsOpen(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="flex-1"
            >
              {loading ? 'Salvando...' : 'Salvar'}
            </Button>
          </div>
        </form>
      </Modal>

      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </>
  );
};