import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Card } from '../ui/Card';

interface ExpenseChartProps {
  data: Array<{ category: string; value: number; color: string }> | Array<{ date: string; amount: number }>;
  type: 'pie' | 'line';
  title: string;
}

export const ExpenseChart: React.FC<ExpenseChartProps> = ({ data, type, title }) => {
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      if (type === 'pie') {
        return (
          <div className="bg-white p-3 border rounded-lg shadow-lg">
            <p className="font-medium">{payload[0].payload.category}</p>
            <p className="text-green-600">{formatCurrency(payload[0].value)}</p>
          </div>
        );
      } else {
        return (
          <div className="bg-white p-3 border rounded-lg shadow-lg">
            <p className="font-medium">{label}</p>
            <p className="text-green-600">{formatCurrency(payload[0].value)}</p>
          </div>
        );
      }
    }
    return null;
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">{title}</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          {type === 'pie' ? (
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ category, percent }: any) => `${category} ${(percent * 100).toFixed(0)}%`}
              >
                {(data as Array<{ category: string; value: number; color: string }>).map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tick={{ fontSize: 12 }}
                interval="preserveStartEnd"
              />
              <YAxis 
                tick={{ fontSize: 12 }}
                tickFormatter={formatCurrency}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line 
                type="monotone" 
                dataKey="amount" 
                stroke="#10B981" 
                strokeWidth={3}
                dot={{ fill: '#10B981', strokeWidth: 2 }}
                activeDot={{ r: 6, fill: '#10B981' }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </Card>
  );
};