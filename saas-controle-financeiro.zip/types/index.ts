export interface User {
  id: string
  name: string
  email: string
  phone?: string
  familyId: string
  role: "admin" | "member"
  createdAt: Date
  updatedAt: Date
}

export interface Family {
  id: string
  name: string
  createdAt: Date
  updatedAt: Date
}

export interface Category {
  id: string
  name: string
  color: string
  icon: string
  familyId: string
  createdAt: Date
  updatedAt: Date
}

export interface Expense {
  id: string
  description: string
  amount: number
  categoryId: string
  userId: string
  familyId: string
  date: Date
  createdAt: Date
  updatedAt: Date
}

export interface CreateExpenseRequest {
  description: string
  amount: number
  categoryId: string
  date: string
}

export interface CreateCategoryRequest {
  name: string
  color: string
  icon: string
}

export interface CreateFamilyRequest {
  name: string
  adminName: string
  adminEmail: string
  adminPhone?: string
}
