"use client"

import { useState, useEffect } from "react"
import type { User, Family } from "@/types"

interface FamilyWithUsers extends Family {
  users: User[]
}

export function useFamilies() {
  const [families, setFamilies] = useState<FamilyWithUsers[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchFamilies = async () => {
    try {
      setLoading(true)
      // Como não temos endpoint para listar todas as famílias, vamos simular
      // Em uma implementação real, você criaria GET /api/families
      setFamilies([])
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao carregar famílias")
    } finally {
      setLoading(false)
    }
  }

  const createFamily = async (data: { name: string; adminName: string; adminEmail: string }) => {
    try {
      const response = await fetch("/api/families", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || "Erro ao criar família")
      }

      const result = await response.json()

      // Adicionar nova família à lista
      const newFamily: FamilyWithUsers = {
        ...result.data.family,
        users: [result.data.admin],
      }

      setFamilies((prev) => [...prev, newFamily])
      return result.data
    } catch (err) {
      throw err
    }
  }

  const addUserToFamily = async (
    familyId: string,
    userData: { name: string; email: string; role: "admin" | "member" },
  ) => {
    try {
      // Simular adição de usuário - em implementação real, criar endpoint POST /api/families/[id]/users
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        ...userData,
        familyId,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      setFamilies((prev) =>
        prev.map((family) => (family.id === familyId ? { ...family, users: [...family.users, newUser] } : family)),
      )

      return newUser
    } catch (err) {
      throw err
    }
  }

  useEffect(() => {
    fetchFamilies()
  }, [])

  return {
    families,
    loading,
    error,
    createFamily,
    addUserToFamily,
    refetch: fetchFamilies,
  }
}
