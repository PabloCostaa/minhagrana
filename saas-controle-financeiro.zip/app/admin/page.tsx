"use client"

import { useState, useEffect } from "react"
import { CreateFamilyForm } from "@/components/admin/create-family-form"
import { FamiliesList } from "@/components/admin/families-list"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Settings, Users, TrendingUp, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { User, Family } from "@/types"

interface FamilyWithUsers extends Family {
  users: User[]
}

export default function AdminPage() {
  const [families, setFamilies] = useState<FamilyWithUsers[]>([])
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [loading, setLoading] = useState(true)

  // Carregar famílias existentes
  useEffect(() => {
    loadFamilies()
  }, [])

  const loadFamilies = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/families")
      const data = await response.json()

      if (response.ok) {
        // Para cada família, carregar seus usuários
        const familiesWithUsers = await Promise.all(
          data.data.map(async (family: Family) => {
            try {
              const usersResponse = await fetch(`/api/families/${family.id}/users`)
              const usersData = await usersResponse.json()
              return {
                ...family,
                users: usersData.success ? usersData.data : [],
              }
            } catch (error) {
              console.error(`Erro ao carregar usuários da família ${family.name}:`, error)
              return {
                ...family,
                users: [],
              }
            }
          }),
        )
        setFamilies(familiesWithUsers)
      } else {
        console.error("Erro ao carregar famílias:", data.error)
      }
    } catch (error) {
      console.error("Erro ao carregar famílias:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFamilyCreated = (data: { family: Family; admin: User }) => {
    const newFamily: FamilyWithUsers = {
      ...data.family,
      users: [data.admin],
    }

    setFamilies((prev) => [newFamily, ...prev])
    setSuccessMessage(`Família "${data.family.name}" criada com sucesso!`)
    setShowCreateForm(false) // Fechar formulário no mobile após criar

    // Limpar mensagem após 5 segundos
    setTimeout(() => setSuccessMessage(null), 5000)
  }

  const handleUserAdded = (familyId: string, user: User) => {
    setFamilies((prev) =>
      prev.map((family) => (family.id === familyId ? { ...family, users: [...family.users, user] } : family)),
    )
    setSuccessMessage(`Usuário "${user.name}" adicionado com sucesso!`)
    setTimeout(() => setSuccessMessage(null), 5000)
  }

  const handleUserUpdated = (updatedUser: User) => {
    setFamilies((prev) =>
      prev.map((family) => {
        if (family.id === updatedUser.familyId) {
          return { ...family, users: family.users.map((u) => (u.id === updatedUser.id ? updatedUser : u)) }
        }
        return family
      }),
    )
    setSuccessMessage(`Usuário "${updatedUser.name}" atualizado com sucesso!`)
    setTimeout(() => setSuccessMessage(null), 5000)
  }

  const handleUserDeleted = (userId: string, familyId: string, userName: string) => {
    setFamilies((prev) =>
      prev.map((family) => {
        if (family.id === familyId) {
          return { ...family, users: family.users.filter((u) => u.id !== userId) }
        }
        return family
      }),
    )
    setSuccessMessage(`Usuário "${userName}" excluído com sucesso!`)
    setTimeout(() => setSuccessMessage(null), 5000)
  }

  const totalUsers = families.reduce((sum, family) => sum + family.users.length, 0)
  const totalAdmins = families.reduce(
    (sum, family) =>
      sum + family.users.filter((user) => typeof user?.role === "string" && user.role === "admin").length,
    0,
  )

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando famílias...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-4 px-4 sm:py-8">
        {/* Header responsivo */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2 sm:gap-3 mb-2">
            <Settings className="h-6 w-6 sm:h-8 sm:w-8" />
            <span className="hidden sm:inline">Painel Administrativo</span>
            <span className="sm:hidden">Admin</span>
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">Gerencie famílias e usuários da plataforma</p>
        </div>

        {successMessage && (
          <Alert className="mb-4 sm:mb-6 border-green-200 bg-green-50">
            <AlertDescription className="text-green-800 text-sm">{successMessage}</AlertDescription>
          </Alert>
        )}

        {/* Estatísticas - Grid responsivo */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-6 sm:mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Famílias</CardTitle>
              <Users className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{families.length}</div>
              <p className="text-xs text-muted-foreground">Cadastradas</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Usuários</CardTitle>
              <Users className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{totalUsers}</div>
              <p className="text-xs text-muted-foreground">Ativos</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Admins</CardTitle>
              <Settings className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">{totalAdmins}</div>
              <p className="text-xs text-muted-foreground">Com permissões</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-xs sm:text-sm font-medium">Média</CardTitle>
              <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-xl sm:text-2xl font-bold">
                {families.length > 0 ? (totalUsers / families.length).toFixed(1) : "0"}
              </div>
              <p className="text-xs text-muted-foreground">Por família</p>
            </CardContent>
          </Card>
        </div>

        {/* Botão para mostrar formulário no mobile */}
        <div className="lg:hidden mb-4">
          <Button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="w-full"
            variant={showCreateForm ? "secondary" : "default"}
          >
            <Menu className="h-4 w-4 mr-2" />
            {showCreateForm ? "Ocultar Formulário" : "Nova Família"}
          </Button>
        </div>

        {/* Layout responsivo - Stack no mobile, side-by-side no desktop */}
        <div className="space-y-6 lg:space-y-0 lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Formulário de criação */}
          <div className={`lg:col-span-1 ${!showCreateForm && "hidden lg:block"}`}>
            <CreateFamilyForm onSuccess={handleFamilyCreated} />
          </div>

          {/* Lista de famílias */}
          <div className="lg:col-span-2">
            <div className="mb-4 sm:mb-6">
              <h2 className="text-xl sm:text-2xl font-semibold mb-2">Famílias Cadastradas</h2>
              <p className="text-sm sm:text-base text-muted-foreground">Visualize e gerencie todas as famílias</p>
            </div>
            <FamiliesList
              families={families}
              onUserAdded={handleUserAdded}
              onUserUpdated={handleUserUpdated}
              onUserDeleted={handleUserDeleted}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
