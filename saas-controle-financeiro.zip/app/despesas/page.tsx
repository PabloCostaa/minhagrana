"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Loader2, Plus, ArrowLeft, CheckCircle, DollarSign } from "lucide-react"

interface Category {
  id: string
  name: string
  color: string
  icon: string
}

interface User {
  id: string
  name: string
  familyId: string
}

interface Family {
  id: string
  name: string
}

export default function DespesasPage() {
  const [user, setUser] = useState<User | null>(null)
  const [family, setFamily] = useState<Family | null>(null)
  const [categories, setCategories] = useState<Category[]>([])
  const [formData, setFormData] = useState({
    description: "",
    amount: "",
  })
  const [suggestedCategory, setSuggestedCategory] = useState<Category | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [pageLoading, setPageLoading] = useState(true)
  const router = useRouter()

  // Mapeamento de palavras-chave para categorias
  const categoryKeywords = {
    alimentacao: [
      "supermercado",
      "mercado",
      "padaria",
      "restaurante",
      "lanche",
      "comida",
      "pizza",
      "hamburguer",
      "açougue",
      "hortifruti",
      "feira",
      "delivery",
      "ifood",
      "uber eats",
    ],
    transporte: [
      "combustivel",
      "gasolina",
      "etanol",
      "diesel",
      "uber",
      "99",
      "taxi",
      "onibus",
      "metro",
      "trem",
      "estacionamento",
      "pedagio",
      "manutencao carro",
      "oficina",
    ],
    moradia: [
      "aluguel",
      "condominio",
      "luz",
      "agua",
      "gas",
      "internet",
      "telefone",
      "iptu",
      "reforma",
      "material construcao",
      "eletricista",
      "encanador",
    ],
    saude: [
      "farmacia",
      "medico",
      "dentista",
      "hospital",
      "exame",
      "consulta",
      "remedio",
      "plano saude",
      "laboratorio",
      "fisioterapia",
    ],
    educacao: [
      "escola",
      "faculdade",
      "curso",
      "livro",
      "material escolar",
      "mensalidade",
      "professor particular",
      "creche",
    ],
    lazer: [
      "cinema",
      "teatro",
      "show",
      "viagem",
      "hotel",
      "parque",
      "jogo",
      "streaming",
      "netflix",
      "spotify",
      "academia",
      "esporte",
    ],
  }

  useEffect(() => {
    // Verificar autenticação
    const userData = localStorage.getItem("user")
    const familyData = localStorage.getItem("family")

    if (!userData || !familyData) {
      router.push("/login")
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      const parsedFamily = JSON.parse(familyData)
      setUser(parsedUser)
      setFamily(parsedFamily)

      // Carregar categorias
      loadCategories(parsedFamily.id)
    } catch (error) {
      console.error("Erro ao carregar dados:", error)
      router.push("/login")
    }
  }, [router])

  // Sugerir categoria padrão quando categorias carregarem
  useEffect(() => {
    if (categories.length > 0 && !suggestedCategory) {
      const defaultCategory =
        categories.find(
          (cat) => cat.name.toLowerCase().includes("alimentacao") || cat.name.toLowerCase().includes("alimentação"),
        ) || categories[0]
      setSuggestedCategory(defaultCategory)
    }
  }, [categories, suggestedCategory])

  const loadCategories = async (familyId: string) => {
    try {
      const response = await fetch(`/api/families/${familyId}/categories`)
      const data = await response.json()

      if (response.ok) {
        setCategories(data.data || [])
      } else {
        console.error("Erro ao carregar categorias:", data.error)
      }
    } catch (error) {
      console.error("Erro ao carregar categorias:", error)
    } finally {
      setPageLoading(false)
    }
  }

  const suggestCategory = (description: string) => {
    const desc = description.toLowerCase().trim()

    if (!desc || categories.length === 0) {
      // Se não há descrição, manter categoria padrão
      if (!suggestedCategory && categories.length > 0) {
        const defaultCategory =
          categories.find(
            (cat) => cat.name.toLowerCase().includes("alimentacao") || cat.name.toLowerCase().includes("alimentação"),
          ) || categories[0]
        setSuggestedCategory(defaultCategory)
      }
      return
    }

    // Primeiro, tentar encontrar por palavras-chave específicas
    for (const [categoryType, keywords] of Object.entries(categoryKeywords)) {
      for (const keyword of keywords) {
        if (desc.includes(keyword)) {
          const category = categories.find(
            (cat) =>
              cat.name.toLowerCase().includes(categoryType.replace("_", "")) ||
              cat.name.toLowerCase().includes(keyword),
          )
          if (category) {
            setSuggestedCategory(category)
            return
          }
        }
      }
    }

    // Se não encontrou por palavra-chave, manter categoria atual ou sugerir padrão
    if (!suggestedCategory) {
      const defaultCategory =
        categories.find(
          (cat) => cat.name.toLowerCase().includes("alimentacao") || cat.name.toLowerCase().includes("alimentação"),
        ) || categories[0]
      setSuggestedCategory(defaultCategory)
    }
  }

  const handleDescriptionChange = (value: string) => {
    setFormData((prev) => ({ ...prev, description: value }))
    if (value.length > 2) {
      suggestCategory(value)
    }
    // Limpar mensagens de erro/sucesso ao digitar
    if (error) setError(null)
    if (success) setSuccess(null)
  }

  const handleAmountChange = (value: string) => {
    // Permitir apenas números e vírgula/ponto
    const cleanValue = value.replace(/[^\d.,]/g, "").replace(",", ".")
    setFormData((prev) => ({ ...prev, amount: cleanValue }))
    // Limpar mensagens de erro/sucesso ao digitar
    if (error) setError(null)
    if (success) setSuccess(null)
  }

  const isFormValid = () => {
    return (
      formData.description.trim().length > 0 &&
      formData.amount.trim().length > 0 &&
      !isNaN(Number.parseFloat(formData.amount)) &&
      Number.parseFloat(formData.amount) > 0 &&
      suggestedCategory !== null
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!user || !family || !suggestedCategory) {
      setError("Dados incompletos para criar despesa")
      return
    }

    if (!isFormValid()) {
      setError("Por favor, preencha todos os campos corretamente")
      return
    }

    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const amount = Number.parseFloat(formData.amount)
      if (isNaN(amount) || amount <= 0) {
        throw new Error("Valor deve ser um número positivo")
      }

      const response = await fetch(`/api/families/${family.id}/expenses`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          description: formData.description.trim(),
          amount: amount,
          categoryId: suggestedCategory.id,
          date: new Date().toISOString().split("T")[0], // Data atual
          userId: user.id, // Incluir ID do usuário
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao criar despesa")
      }

      setSuccess(`Despesa "${formData.description}" cadastrada com sucesso!`)

      // Limpar formulário
      setFormData({ description: "", amount: "" })

      // Manter categoria sugerida para próxima despesa
      const defaultCategory =
        categories.find(
          (cat) => cat.name.toLowerCase().includes("alimentacao") || cat.name.toLowerCase().includes("alimentação"),
        ) || categories[0]
      setSuggestedCategory(defaultCategory)

      // Limpar mensagem de sucesso após 3 segundos
      setTimeout(() => setSuccess(null), 3000)
    } catch (err) {
      console.error("Erro ao criar despesa:", err)
      setError(err instanceof Error ? err.message : "Erro desconhecido")
    } finally {
      setLoading(false)
    }
  }

  // Debug log
  console.log("Debug - Form state:", {
    description: formData.description,
    amount: formData.amount,
    suggestedCategory: suggestedCategory?.name,
    isFormValid: isFormValid(),
    buttonDisabled: loading || !isFormValid(),
  })

  if (pageLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!user || !family) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-4 px-4 sm:py-8 max-w-2xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="sm" onClick={() => router.push("/dashboard")} className="p-2">
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Nova Despesa</h1>
            <p className="text-sm sm:text-base text-gray-600">Registre um novo gasto da {family.name}</p>
          </div>
        </div>

        {/* Formulário */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Cadastrar Despesa
            </CardTitle>
            <CardDescription>
              Digite o nome do item e o valor. A categoria será sugerida automaticamente.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription className="text-sm">{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 text-sm">{success}</AlertDescription>
                </Alert>
              )}

              {/* Nome do Item */}
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-medium">
                  Nome do Item *
                </Label>
                <Input
                  id="description"
                  type="text"
                  placeholder="Ex: Supermercado Pão de Açúcar"
                  value={formData.description}
                  onChange={(e) => handleDescriptionChange(e.target.value)}
                  required
                  disabled={loading}
                  className="h-11"
                />
              </div>

              {/* Valor */}
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-sm font-medium">
                  Valor *
                </Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                  <Input
                    id="amount"
                    type="text"
                    placeholder="0,00"
                    value={formData.amount}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    required
                    disabled={loading}
                    className="h-11 pl-10"
                  />
                </div>
              </div>

              {/* Categoria Sugerida */}
              {suggestedCategory && (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Categoria Sugerida</Label>
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center text-lg"
                      style={{ backgroundColor: suggestedCategory.color + "20" }}
                    >
                      {suggestedCategory.icon}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-sm">{suggestedCategory.name}</p>
                      <p className="text-xs text-gray-600">
                        {formData.description.trim() ? "Categoria detectada automaticamente" : "Categoria padrão"}
                      </p>
                    </div>
                    <Badge
                      variant="secondary"
                      className="text-xs"
                      style={{
                        backgroundColor: suggestedCategory.color,
                        color: "white",
                      }}
                    >
                      {formData.description.trim() ? "Auto" : "Padrão"}
                    </Badge>
                  </div>
                </div>
              )}

              {/* Data (apenas informativa) */}
              <div className="space-y-2">
                <Label className="text-sm font-medium">Data</Label>
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="text-sm text-gray-700">
                    {new Date().toLocaleDateString("pt-BR", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">Data será registrada automaticamente</p>
                </div>
              </div>

              {/* Botão de Submit */}
              <Button type="submit" disabled={loading || !isFormValid()} className="w-full h-11">
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                <Plus className="mr-2 h-4 w-4" />
                {loading ? "Cadastrando..." : "Cadastrar Despesa"}
              </Button>

              {/* Debug info (remover em produção) */}
              {process.env.NODE_ENV === "development" && (
                <div className="text-xs text-gray-500 p-2 bg-gray-100 rounded">
                  Debug: Descrição: "{formData.description}" | Valor: "{formData.amount}" | Categoria:{" "}
                  {suggestedCategory?.name || "Nenhuma"} | Válido: {isFormValid() ? "Sim" : "Não"}
                </div>
              )}
            </form>
          </CardContent>
        </Card>

        {/* Dicas */}
        <Card className="mt-6 bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <h3 className="font-semibold text-sm mb-2 text-blue-900">💡 Dicas para melhor categorização:</h3>
            <ul className="text-xs text-blue-800 space-y-1">
              <li>• Use nomes específicos: "Supermercado Extra" em vez de "Compras"</li>
              <li>• Inclua o local: "Posto Shell", "Farmácia Drogasil"</li>
              <li>• Para transporte: "Uber", "Gasolina", "Estacionamento"</li>
              <li>• Para casa: "Conta de luz", "Aluguel", "Condomínio"</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
