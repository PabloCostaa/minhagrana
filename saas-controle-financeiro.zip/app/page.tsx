"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, Settings, ArrowRight } from "lucide-react"

export default function HomePage() {
  const router = useRouter()

  useEffect(() => {
    // Verificar se já está logado
    const userData = localStorage.getItem("user")
    if (userData) {
      router.push("/dashboard")
    }
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8 sm:py-16">
        <div className="text-center mb-12">
          <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
            <Users className="h-8 w-8 text-blue-600" />
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
            Controle Financeiro Familiar
          </h1>
          <p className="text-lg sm:text-xl text-gray-600 max-w-2xl mx-auto">
            Gerencie as despesas da sua família de forma simples e organizada. Acompanhe gastos, categorize despesas e
            mantenha o orçamento em dia.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
          <Card className="text-center">
            <CardHeader>
              <CardTitle className="flex items-center justify-center gap-2">
                <Users className="h-6 w-6 text-blue-600" />
                Para Famílias
              </CardTitle>
              <CardDescription>Acesse sua conta familiar e gerencie suas despesas</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => router.push("/login")} className="w-full" size="lg">
                Entrar na Família
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <CardTitle className="flex items-center justify-center gap-2">
                <Settings className="h-6 w-6 text-green-600" />
                Para Administradores
              </CardTitle>
              <CardDescription>Gerencie famílias e usuários do sistema</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => router.push("/admin")} variant="outline" className="w-full" size="lg">
                Área Administrativa
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-sm text-gray-500">Não tem acesso? Entre em contato com o administrador da sua família.</p>
        </div>
      </div>
    </div>
  )
}
