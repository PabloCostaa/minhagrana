import { NextResponse, type NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, normalizePhone } from "@/lib/api-utils"

export async function POST(req: NextRequest) {
  try {
    // 1. Parse & validate body
    let body: { name?: string; phone?: string }
    try {
      body = await req.json()
    } catch {
      return createErrorResponse("Corpo da requisição inválido – JSON esperado", 400)
    }

    // Pelo menos um dos campos deve existir
    if (!body.name && !body.phone) {
      return createErrorResponse("Informe nome, telefone ou ambos.", 400)
    }

    const phoneDigits = normalizePhone(body.phone) // pode ser ""
    const rawPhone = body.phone

    let user = undefined

    // 2a. nome + telefone (quando ambos presentes)
    if (body.name && phoneDigits) {
      user = await db.getUserByNameAndPhone(body.name.trim(), phoneDigits)
    }

    // 2b. apenas nome
    if (!user && body.name) {
      user = await db.getUserByNameAndPhone(body.name.trim(), "")
    }

    // 2c. apenas telefone
    if (!user && phoneDigits) {
      user = await db.getUserByNameAndPhone("", phoneDigits)
    }

    if (!user) {
      return createErrorResponse("Usuário não encontrado. Verifique os dados digitados.", 404)
    }

    // 3. Buscar dados da família
    const family = await db.getFamilyById(user.familyId || user.family_id)

    if (!family) {
      return createErrorResponse("Família não encontrada.", 404)
    }

    // 4. Retornar dados do usuário e família
    return createSuccessResponse({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        familyId: user.familyId || user.family_id,
      },
      family: {
        id: family.id,
        name: family.name,
      },
    })
  } catch (err) {
    console.error("POST /api/auth/login failed:", err)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
