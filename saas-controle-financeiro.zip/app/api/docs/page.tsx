export default function ApiDocs() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-4 sm:p-8">
        <h1 className="text-2xl sm:text-3xl font-bold mb-6 sm:mb-8">API de Controle de Despesas Familiar</h1>

        <div className="space-y-6 sm:space-y-8">
          <section>
            <h2 className="text-xl sm:text-2xl font-semibold mb-4">Visão Geral</h2>
            <p className="text-sm sm:text-base text-gray-600 mb-4">
              Esta API REST permite gerenciar despesas familiares, incluindo criação de famílias, categorias de
              despesas, registro de gastos e geração de relatórios.
            </p>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-semibold mb-4">Endpoints</h2>

            <div className="space-y-4 sm:space-y-6">
              <div className="border rounded-lg p-3 sm:p-4 bg-white">
                <h3 className="text-base sm:text-lg font-medium mb-2">Famílias</h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-green-100 px-2 py-1 rounded text-xs">POST</span>
                    <code className="text-xs sm:text-sm">/api/families</code>
                    <span className="text-muted-foreground">- Criar nova família</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-3 sm:p-4 bg-white">
                <h3 className="text-base sm:text-lg font-medium mb-2">Categorias</h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-blue-100 px-2 py-1 rounded text-xs">GET</span>
                    <code className="text-xs sm:text-sm break-all">/api/families/[familyId]/categories</code>
                    <span className="text-muted-foreground">- Listar categorias</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-green-100 px-2 py-1 rounded text-xs">POST</span>
                    <code className="text-xs sm:text-sm break-all">/api/families/[familyId]/categories</code>
                    <span className="text-muted-foreground">- Criar categoria</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-red-100 px-2 py-1 rounded text-xs">DELETE</span>
                    <code className="text-xs sm:text-sm break-all">/api/categories/[categoryId]</code>
                    <span className="text-muted-foreground">- Deletar categoria</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-3 sm:p-4 bg-white">
                <h3 className="text-base sm:text-lg font-medium mb-2">Despesas</h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-blue-100 px-2 py-1 rounded text-xs">GET</span>
                    <code className="text-xs sm:text-sm break-all">/api/families/[familyId]/expenses</code>
                    <span className="text-muted-foreground">- Listar despesas</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-green-100 px-2 py-1 rounded text-xs">POST</span>
                    <code className="text-xs sm:text-sm break-all">/api/families/[familyId]/expenses</code>
                    <span className="text-muted-foreground">- Criar despesa</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-yellow-100 px-2 py-1 rounded text-xs">PUT</span>
                    <code className="text-xs sm:text-sm break-all">/api/expenses/[expenseId]</code>
                    <span className="text-muted-foreground">- Atualizar despesa</span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-red-100 px-2 py-1 rounded text-xs">DELETE</span>
                    <code className="text-xs sm:text-sm break-all">/api/expenses/[expenseId]</code>
                    <span className="text-muted-foreground">- Deletar despesa</span>
                  </div>
                </div>
              </div>

              <div className="border rounded-lg p-3 sm:p-4 bg-white">
                <h3 className="text-base sm:text-lg font-medium mb-2">Relatórios</h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                    <span className="font-mono bg-blue-100 px-2 py-1 rounded text-xs">GET</span>
                    <code className="text-xs sm:text-sm break-all">/api/families/[familyId]/reports</code>
                    <span className="text-muted-foreground">- Relatório mensal</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-semibold mb-4">Exemplos de Uso</h2>

            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2 text-sm sm:text-base">Criar uma família:</h4>
                <pre className="bg-gray-100 p-3 sm:p-4 rounded text-xs sm:text-sm overflow-x-auto">
                  {`POST /api/families
{
  "name": "Família Silva",
  "adminName": "João Silva",
  "adminEmail": "joao@silva.com",
  "adminPhone": "(11) 99999-9999"
}`}
                </pre>
              </div>

              <div>
                <h4 className="font-medium mb-2 text-sm sm:text-base">Criar uma despesa:</h4>
                <pre className="bg-gray-100 p-3 sm:p-4 rounded text-xs sm:text-sm overflow-x-auto">
                  {`POST /api/families/[familyId]/expenses
{
  "description": "Supermercado",
  "amount": 150.50,
  "categoryId": "cat123",
  "date": "2024-01-15"
}`}
                </pre>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-xl sm:text-2xl font-semibold mb-4">Dados Iniciais</h2>
            <p className="text-sm sm:text-base text-gray-600">
              A API já vem com dados de exemplo incluindo uma família "Família Silva" e categorias padrão como
              Alimentação, Transporte, Moradia, Saúde, Educação e Lazer.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
