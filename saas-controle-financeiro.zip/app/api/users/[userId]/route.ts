import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateEmail } from "@/lib/api-utils"
import type { User } from "@/types"

export async function PUT(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const { userId } = params
    const body = await request.json()

    const user = await db.getUserById(userId)
    if (!user) {
      return createErrorResponse("Usuário não encontrado", 404)
    }

    const updates: Partial<User> = {}
    if (body.name !== undefined) updates.name = body.name
    if (body.email !== undefined) {
      validateEmail(body.email)
      const existing = await db.getUserByEmail(body.email)
      if (existing && existing.id !== userId) {
        return createErrorResponse("Email já está em uso por outro usuário", 409)
      }
      updates.email = body.email
    }
    if (body.phone !== undefined) updates.phone = body.phone
    if (body.role !== undefined) {
      if (!["admin", "member"].includes(body.role)) {
        return createErrorResponse("Função inválida", 400)
      }
      updates.role = body.role
    }

    if (Object.keys(updates).length === 0) {
      return createErrorResponse("Nenhum campo para atualizar", 400)
    }

    const updatedUser = await db.updateUser(userId, updates)
    return createSuccessResponse(updatedUser)
  } catch (error) {
    console.error("Erro ao atualizar usuário:", error)
    return createErrorResponse(error instanceof Error ? error.message : "Erro interno do servidor", 500)
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const { userId } = params

    const user = await db.getUserById(userId)
    if (!user) {
      return createErrorResponse("Usuário não encontrado", 404)
    }

    // Regra de negócio: não permitir exclusão do último admin da família
    if (user.role === "admin") {
      const familyUsers = await db.getUsersByFamilyId(user.familyId)
      const admins = familyUsers.filter((u) => u.role === "admin")
      if (admins.length <= 1) {
        return createErrorResponse("Não é possível excluir o único administrador da família", 403)
      }
    }

    await db.deleteUser(userId)
    return createSuccessResponse({ message: "Usuário excluído com sucesso" })
  } catch (error) {
    console.error("Erro ao excluir usuário:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}
