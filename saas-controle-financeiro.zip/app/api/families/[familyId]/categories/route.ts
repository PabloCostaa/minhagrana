import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateRequired } from "@/lib/api-utils"
import type { CreateCategoryRequest } from "@/types"

export async function GET(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    const categories = await db.getCategoriesByFamilyId(familyId)
    return createSuccessResponse(categories)
  } catch (error) {
    console.error("Erro ao buscar categorias:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}

export async function POST(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params
    const body: CreateCategoryRequest = await request.json()

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    validateRequired({
      name: body.name,
      color: body.color,
      icon: body.icon,
    })

    const category = await db.createCategory(body.name, body.color, body.icon, familyId)

    return createSuccessResponse(category, 201)
  } catch (error) {
    console.error("Erro ao criar categoria:", error)
    if (error instanceof Error && error.message.includes("duplicate key")) {
      return createErrorResponse("Já existe uma categoria com este nome nesta família", 409)
    }
    return createErrorResponse(error instanceof Error ? error.message : "Erro interno do servidor", 500)
  }
}
