import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse } from "@/lib/api-utils"

export async function GET(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params
    const { searchParams } = new URL(request.url)

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    const month = Number.parseInt(searchParams.get("month") || new Date().getMonth().toString())
    const year = Number.parseInt(searchParams.get("year") || new Date().getFullYear().toString())

    const report = await db.getMonthlyReport(familyId, month, year)

    const monthNames = [
      "janeiro",
      "fevereiro",
      "março",
      "abril",
      "maio",
      "junho",
      "julho",
      "agosto",
      "setembro",
      "outubro",
      "novembro",
      "dezembro",
    ]

    const response = {
      period: {
        month,
        year,
        monthName: monthNames[month],
      },
      ...report,
    }

    return createSuccessResponse(response)
  } catch (error) {
    console.error("Erro ao gerar relatório:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}
