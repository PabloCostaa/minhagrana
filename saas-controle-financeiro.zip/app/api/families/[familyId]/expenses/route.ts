import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateRequired, validateAmount } from "@/lib/api-utils"
import type { CreateExpenseRequest } from "@/types"

export async function GET(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params
    const { searchParams } = new URL(request.url)

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    // Filtros opcionais
    const filters: any = {}

    const categoryId = searchParams.get("categoryId")
    if (categoryId) filters.categoryId = categoryId

    const startDate = searchParams.get("startDate")
    if (startDate) filters.startDate = new Date(startDate)

    const endDate = searchParams.get("endDate")
    if (endDate) filters.endDate = new Date(endDate)

    const limit = searchParams.get("limit")
    if (limit) filters.limit = Number.parseInt(limit)

    const offset = searchParams.get("offset")
    if (offset) filters.offset = Number.parseInt(offset)

    const expenses = await db.getExpensesByFamilyId(familyId, filters)

    return createSuccessResponse(expenses)
  } catch (error) {
    console.error("Erro ao buscar despesas:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}

export async function POST(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params
    const body: CreateExpenseRequest & { userId?: string } = await request.json()

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    validateRequired({
      description: body.description,
      amount: body.amount,
      categoryId: body.categoryId,
      date: body.date,
    })

    validateAmount(body.amount)

    const category = await db.getCategoryById(body.categoryId)
    if (!category) {
      return createErrorResponse("Categoria não encontrada", 404)
    }

    /**
     * Banco de dados retorna `family_id`, enquanto o fallback em memória usa `familyId`.
     * Precisamos considerar ambos para não gerar erro falso.
     */
    const categoryFamilyId = (category as any).family_id ?? (category as any).familyId

    if (categoryFamilyId !== familyId) {
      return createErrorResponse("Categoria não pertence a esta família", 403)
    }

    // Usar userId fornecido ou pegar o primeiro usuário da família
    let userId = body.userId
    if (!userId) {
      const users = await db.getUsersByFamilyId(familyId)
      if (users.length === 0) {
        return createErrorResponse("Nenhum usuário encontrado na família", 404)
      }
      userId = users[0].id
    }

    const expense = await db.createExpense(
      body.description,
      body.amount,
      body.categoryId,
      userId,
      familyId,
      new Date(body.date),
    )

    return createSuccessResponse(expense, 201)
  } catch (error) {
    console.error("Erro ao criar despesa:", error)
    return createErrorResponse(error instanceof Error ? error.message : "Erro interno do servidor", 500)
  }
}
