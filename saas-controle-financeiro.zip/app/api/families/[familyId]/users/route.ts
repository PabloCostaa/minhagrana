import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateRequired, validateEmail } from "@/lib/api-utils"

export async function GET(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    const users = await db.getUsersByFamilyId(familyId)
    return createSuccessResponse(users)
  } catch (error) {
    console.error("Erro ao buscar usuários:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}

export async function POST(request: NextRequest, { params }: { params: { familyId: string } }) {
  try {
    const { familyId } = params
    const body = await request.json()

    const family = await db.getFamilyById(familyId)
    if (!family) {
      return createErrorResponse("Família não encontrada", 404)
    }

    validateRequired({
      name: body.name,
      email: body.email,
      role: body.role,
    })

    validateEmail(body.email)

    if (!["admin", "member"].includes(body.role)) {
      return createErrorResponse("Função deve ser 'admin' ou 'member'")
    }

    // Verificar se email já existe
    const existingUser = await db.getUserByEmail(body.email)
    if (existingUser) {
      return createErrorResponse("Email já está em uso")
    }

    const user = await db.createUser(body.name, body.email, body.phone, familyId, body.role)

    return createSuccessResponse(user, 201)
  } catch (error) {
    console.error("Erro ao criar usuário:", error)
    return createErrorResponse(error instanceof Error ? error.message : "Erro interno do servidor", 500)
  }
}
