import { NextResponse, type NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateRequired, validateEmail } from "@/lib/api-utils"
import type { CreateFamilyRequest } from "@/types"

export async function GET() {
  try {
    const families = await db.getAllFamilies()
    return createSuccessResponse(families)
  } catch (err) {
    console.error("GET /api/families failed:", err)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    // 1. Parse & validate body ------------------------------------------------
    let body: CreateFamilyRequest
    try {
      body = await req.json()
    } catch {
      return createErrorResponse("Corpo da requisição inválido – JSON esperado", 400)
    }

    validateRequired({
      name: body.name,
      adminName: body.adminName,
      adminEmail: body.adminEmail,
    })
    // adminPhone é opcional, então não precisa validar como required
    validateEmail(body.adminEmail)

    // 2. E-mail already used? --------------------------------------------------
    if (await db.getUserByEmail(body.adminEmail)) {
      return createErrorResponse("Email já está em uso", 409)
    }

    // 3. Create family & admin -------------------------------------------------
    const family = await db.createFamily(body.name)
    const admin = await db.createUser(body.adminName, body.adminEmail, body.adminPhone, family.id, "admin")

    return createSuccessResponse({ family, admin }, 201)
  } catch (err) {
    // Anything that escaped our checks
    console.error("POST /api/families failed:", err)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
