import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse } from "@/lib/api-utils"

export async function GET() {
  try {
    const connectionTest = await db.testConnection()

    if (connectionTest.success) {
      return createSuccessResponse({
        status: "healthy",
        database: "connected",
        timestamp: connectionTest.timestamp,
      })
    } else {
      return createErrorResponse(`Erro de conexão com banco: ${connectionTest.error}`, 503)
    }
  } catch (error) {
    return createErrorResponse("Erro interno do servidor", 500)
  }
}
