import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse } from "@/lib/api-utils"

export async function DELETE(request: NextRequest, { params }: { params: { categoryId: string } }) {
  try {
    const { categoryId } = params

    const category = await db.getCategoryById(categoryId)
    if (!category) {
      return createErrorResponse("Categoria não encontrada", 404)
    }

    await db.deleteCategory(categoryId)

    return createSuccessResponse({ message: "Categoria deletada com sucesso" })
  } catch (error) {
    console.error("Erro ao deletar categoria:", error)
    if (error instanceof Error && error.message.includes("despesas associadas")) {
      return createErrorResponse(error.message, 409)
    }
    return createErrorResponse("Erro interno do servidor", 500)
  }
}
