import type { NextRequest } from "next/server"
import { db } from "@/lib/database"
import { createErrorResponse, createSuccessResponse, validateAmount } from "@/lib/api-utils"

export async function PUT(request: NextRequest, { params }: { params: { expenseId: string } }) {
  try {
    const { expenseId } = params
    const body = await request.json()

    const expense = await db.getExpenseById(expenseId)
    if (!expense) {
      return createErrorResponse("Despesa não encontrada", 404)
    }

    const updates: any = {}

    if (body.description !== undefined) {
      updates.description = body.description
    }

    if (body.amount !== undefined) {
      validateAmount(body.amount)
      updates.amount = body.amount
    }

    if (body.categoryId !== undefined) {
      const category = await db.getCategoryById(body.categoryId)
      if (!category) {
        return createErrorResponse("Categoria não encontrada", 404)
      }
      updates.categoryId = body.categoryId
    }

    if (body.date !== undefined) {
      updates.expenseDate = new Date(body.date)
    }

    const updatedExpense = await db.updateExpense(expenseId, updates)
    return createSuccessResponse(updatedExpense)
  } catch (error) {
    console.error("Erro ao atualizar despesa:", error)
    return createErrorResponse(error instanceof Error ? error.message : "Erro interno do servidor", 500)
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { expenseId: string } }) {
  try {
    const { expenseId } = params

    const expense = await db.getExpenseById(expenseId)
    if (!expense) {
      return createErrorResponse("Despesa não encontrada", 404)
    }

    await db.deleteExpense(expenseId)

    return createSuccessResponse({ message: "Despesa deletada com sucesso" })
  } catch (error) {
    console.error("Erro ao deletar despesa:", error)
    return createErrorResponse("Erro interno do servidor", 500)
  }
}
