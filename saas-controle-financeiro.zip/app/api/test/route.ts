import { createSuccessResponse, createErrorResponse } from "@/lib/api-utils"
import { db } from "@/lib/database"

export async function GET() {
  try {
    // Testar conexão com banco
    const connectionTest = await db.testConnection()

    return createSuccessResponse({
      message: "API funcionando corretamente",
      database: connectionTest.success ? "conectado" : "erro de conexão",
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV,
      databaseUrl: process.env.DATABASE_URL ? "configurado" : "não configurado",
    })
  } catch (error) {
    console.error("Erro no teste:", error)
    return createErrorResponse("Erro no teste da API", 500)
  }
}
