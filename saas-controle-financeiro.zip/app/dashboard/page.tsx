"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, LogOut, Phone, Mail, Crown, Plus, DollarSign, BarChart3 } from "lucide-react"

interface Family {
  id: string
  name: string
}

export default function DashboardPage() {
  const [user, setUser] = useState<any | null>(null)
  const [family, setFamily] = useState<Family | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    // Verificar se o usuário está logado
    const userData = localStorage.getItem("user")
    const familyData = localStorage.getItem("family")

    if (!userData || !familyData) {
      router.push("/login")
      return
    }

    try {
      setUser(JSON.parse(userData))
      setFamily(JSON.parse(familyData))
    } catch (error) {
      console.error("Erro ao carregar dados do usuário:", error)
      router.push("/login")
    } finally {
      setLoading(false)
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("user")
    localStorage.removeItem("family")
    router.push("/login")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    )
  }

  if (!user || !family) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-4 px-4 sm:py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 sm:mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Olá, {user.name.split(" ")[0]}! 👋</h1>
            <p className="text-sm sm:text-base text-gray-600">Bem-vindo ao controle financeiro da {family.name}</p>
          </div>
          <Button variant="outline" onClick={handleLogout} className="mt-4 sm:mt-0 w-full sm:w-auto bg-transparent">
            <LogOut className="h-4 w-4 mr-2" />
            Sair
          </Button>
        </div>

        {/* Botão de Ação Principal */}
        <div className="mb-8">
          <Button onClick={() => router.push("/despesas")} size="lg" className="w-full sm:w-auto h-12 text-base">
            <Plus className="h-5 w-5 mr-2" />
            Nova Despesa
          </Button>
        </div>

        {/* Informações do usuário */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Suas Informações
              </CardTitle>
              <CardDescription>Dados do seu perfil</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <Users className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Nome</p>
                  <p className="font-medium">{user.name}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{user.email}</p>
                </div>
              </div>

              {user.phone && (
                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <div>
                    <p className="text-sm text-gray-500">Telefone</p>
                    <p className="font-medium">{user.phone}</p>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3">
                {user.role === "admin" ? (
                  <Crown className="h-4 w-4 text-yellow-500" />
                ) : (
                  <Users className="h-4 w-4 text-blue-500" />
                )}
                <div>
                  <p className="text-sm text-gray-500">Função</p>
                  <p className="font-medium">{user.role === "admin" ? "Administrador" : "Membro"}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Sua Família
              </CardTitle>
              <CardDescription>Informações da família</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3">
                <Users className="h-4 w-4 text-gray-500" />
                <div>
                  <p className="text-sm text-gray-500">Nome da Família</p>
                  <p className="font-medium text-lg">{family.name}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Funcionalidades */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => router.push("/despesas")}>
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">Cadastrar Despesa</h3>
              <p className="text-sm text-gray-600 mb-4">Registrar novos gastos rapidamente</p>
              <Button variant="outline" className="w-full bg-transparent">
                Acessar
              </Button>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">Relatórios</h3>
              <p className="text-sm text-gray-600 mb-4">Análises e gráficos</p>
              <Button variant="outline" className="w-full bg-transparent" disabled>
                Em breve
              </Button>
            </CardContent>
          </Card>

          {user.role === "admin" && (
            <Card className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Crown className="h-6 w-6 text-yellow-600" />
                </div>
                <h3 className="font-semibold mb-2">Administração</h3>
                <p className="text-sm text-gray-600 mb-4">Gerenciar famílias e usuários</p>
                <Button variant="outline" className="w-full bg-transparent" onClick={() => router.push("/admin")}>
                  Acessar
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
