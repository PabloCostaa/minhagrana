import { NextResponse } from "next/server"

export function createErrorResponse(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status })
}

export function createSuccessResponse(data: any, status = 200) {
  return NextResponse.json({ success: true, data }, { status })
}

export function validateRequired(fields: Record<string, any>) {
  const missing = Object.entries(fields)
    .filter(([_, value]) => value === undefined || value === null || value === "")
    .map(([key, _]) => key)

  if (missing.length > 0) {
    throw new Error(`Campos obrigatórios ausentes: ${missing.join(", ")}`)
  }
}

export function validateEmail(email: string) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email)) {
    throw new Error("Email inválido")
  }
}

export function validateAmount(amount: number) {
  if (isNaN(amount) || amount <= 0) {
    throw new Error("Valor deve ser um número positivo")
  }
}

// Normaliza telefones removendo todos os caracteres que não sejam dígitos.
export function normalizePhone(phone: string | undefined | null) {
  return (phone || "").replace(/\D/g, "")
}

// Remove acentuação e converte para minúsculas ― útil para comparar nomes.
export function normalizeName(name: string | undefined | null) {
  return (name || "")
    .trim()
    .toLocaleLowerCase("pt-BR")
    .normalize("NFD") // separa acentos
    .replace(/\p{Diacritic}/gu, "") // remove marcas diacríticas
}
