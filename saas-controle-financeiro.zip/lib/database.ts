// We load "pg" dynamically so the code also works in environments
// (like Next.js previews) where the module isn't available.
const Pool: typeof import("pg").Pool | null = null

import crypto from "crypto"
import { normalizePhone, normalizeName } from "@/lib/api-utils"

interface Family {
  id: string
  name: string
  created_at: Date
  updated_at: Date
}

interface User {
  id: string
  name: string
  email: string
  phone?: string
  familyId: string
  role: "admin" | "member"
  created_at: Date
  updated_at: Date
}

interface Category {
  id: string
  name: string
  color: string
  icon: string
  familyId: string
  created_at: Date
  updated_at: Date
}

interface Expense {
  id: string
  description: string
  amount: number
  categoryId: string
  userId: string
  familyId: string
  expenseDate: Date
  created_at: Date
  updated_at: Date
}

// Classe para gerenciar operações do banco de dados
export class PostgresDatabase {
  static isDbReady = true
  private familiesMemory: Family[] = []
  private usersMemory: User[] = []
  private categoriesMemory: Category[] = []
  private expensesMemory: Expense[] = []
  private pool: any

  constructor() {
    /* Seed em memória para ambientes sem banco --------------------------- */
    const demoFamily: Family = {
      id: "550e8400-e29b-41d4-a716-446655440000",
      name: "Família Silva",
      created_at: new Date(),
      updated_at: new Date(),
    }
    const demoUser: User = {
      id: "550e8400-e29b-41d4-a716-446655440001",
      name: "João Silva",
      email: "joao@silva.com",
      phone: "11999999999",
      familyId: demoFamily.id,
      role: "admin",
      created_at: new Date(),
      updated_at: new Date(),
    }

    // Categorias padrão
    const demoCategories: Category[] = [
      {
        id: crypto.randomUUID(),
        name: "Alimentação",
        color: "#FF6B6B",
        icon: "🍽️",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: crypto.randomUUID(),
        name: "Transporte",
        color: "#4ECDC4",
        icon: "🚗",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: crypto.randomUUID(),
        name: "Moradia",
        color: "#45B7D1",
        icon: "🏠",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: crypto.randomUUID(),
        name: "Saúde",
        color: "#96CEB4",
        icon: "🏥",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: crypto.randomUUID(),
        name: "Educação",
        color: "#FFEAA7",
        icon: "📚",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
      {
        id: crypto.randomUUID(),
        name: "Lazer",
        color: "#DDA0DD",
        icon: "🎮",
        familyId: demoFamily.id,
        created_at: new Date(),
        updated_at: new Date(),
      },
    ]

    //  ⚠️  Adiciona somente se ainda não existirem registros em memória
    if (this.familiesMemory.length === 0) this.familiesMemory.push(demoFamily)
    if (this.usersMemory.length === 0) this.usersMemory.push(demoUser)
    if (this.categoriesMemory.length === 0) this.categoriesMemory.push(...demoCategories)

    const hasConnString = Boolean(process.env.DATABASE_URL)
    ;(async () => {
      try {
        if (!hasConnString) throw new Error("DATABASE_URL não definido")

        const pg = await import("pg")
        const { Pool } = pg
        this.pool = new Pool({
          connectionString: process.env.DATABASE_URL,
          ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
        })
        PostgresDatabase.isDbReady = true
        console.info("[database] Pool PostgreSQL criada")
      } catch (err) {
        /* Fallback em memória */
        PostgresDatabase.isDbReady = false
        this.pool = null
        console.warn(
          "[database] PostgreSQL indisponível – usando armazenamento em memória.",
          err instanceof Error ? err.message : err,
        )
      }
    })()
  }

  private hasPool() {
    return PostgresDatabase.isDbReady && this.pool && typeof this.pool.query === "function"
  }

  // Families
  async getAllFamilies() {
    if (!this.hasPool()) {
      return this.familiesMemory
    }
    try {
      const query = "SELECT * FROM families ORDER BY created_at DESC"
      const result = await this.pool.query(query)
      return result.rows
    } catch (error) {
      console.error("Erro ao buscar famílias:", error)
      throw new Error(`Erro ao buscar famílias: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async createFamily(name: string) {
    if (!this.hasPool()) {
      const family = { id: crypto.randomUUID(), name, created_at: new Date(), updated_at: new Date() }
      this.familiesMemory.push(family)
      return family
    }
    try {
      const query = `
        INSERT INTO families (name) 
        VALUES ($1) 
        RETURNING *
      `
      const result = await this.pool.query(query, [name])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao criar família:", error)
      throw new Error(`Erro ao criar família: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getFamilyById(id: string) {
    if (!this.hasPool()) {
      return this.familiesMemory.find((family) => family.id === id) || undefined
    }
    try {
      const query = "SELECT * FROM families WHERE id = $1"
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao buscar família:", error)
      throw new Error(`Erro ao buscar família: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  // Users
  async createUser(name: string, email: string, phone: string | undefined, familyId: string, role: "admin" | "member") {
    if (!this.hasPool()) {
      const user = {
        id: crypto.randomUUID(),
        name,
        email,
        phone,
        familyId,
        role,
        created_at: new Date(),
        updated_at: new Date(),
      }
      this.usersMemory.push(user)
      return user
    }
    try {
      const query = `
        INSERT INTO users (name, email, phone, family_id, role) 
        VALUES ($1, $2, $3, $4, $5) 
        RETURNING *
      `
      const result = await this.pool.query(query, [name, email, phone, familyId, role])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao criar usuário:", error)
      throw new Error(`Erro ao criar usuário: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getUserById(id: string) {
    if (!this.hasPool()) {
      return this.usersMemory.find((user) => user.id === id) || undefined
    }
    try {
      const query = "SELECT * FROM users WHERE id = $1"
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao buscar usuário:", error)
      throw new Error(`Erro ao buscar usuário: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getUsersByFamilyId(familyId: string) {
    if (!this.hasPool()) {
      return this.usersMemory.filter((user) => user.familyId === familyId)
    }
    try {
      const query = "SELECT * FROM users WHERE family_id = $1 ORDER BY created_at"
      const result = await this.pool.query(query, [familyId])
      return result.rows
    } catch (error) {
      console.error("Erro ao buscar usuários da família:", error)
      throw new Error(`Erro ao buscar usuários: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getUserByEmail(email: string) {
    if (!this.hasPool()) {
      return this.usersMemory.find((user) => user.email === email) || undefined
    }
    try {
      const query = "SELECT * FROM users WHERE email = $1"
      const result = await this.pool.query(query, [email])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao buscar usuário por email:", error)
      throw new Error(
        `Erro ao buscar usuário por email: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
      )
    }
  }

  // Novo método para buscar usuário por nome e telefone
  async getUserByNameAndPhone(name: string, phone?: string) {
    const cleanPhone = normalizePhone(phone)
    const cleanName = normalizeName(name)

    const usePhone = cleanPhone.length > 0 // apenas se há dígitos

    /** Procura na base em memória usando as mesmas regras. */
    const searchInMemory = (): User | undefined => {
      const found = this.usersMemory.find((u) => {
        const nameMatch = normalizeName(u.name) === cleanName
        const phoneMatch = usePhone ? normalizePhone(u.phone) === cleanPhone : true
        return nameMatch && phoneMatch
      })
      if (found) return found

      // apenas nome (prefixo)
      if (cleanName) {
        return this.usersMemory.find((u) => normalizeName(u.name).startsWith(cleanName))
      }
      // apenas telefone
      if (!cleanName && cleanPhone) {
        return this.usersMemory.find((u) => normalizePhone(u.phone) === cleanPhone)
      }
      return undefined
    }

    // -------- Fallback em memória ---------
    if (!this.hasPool()) return searchInMemory()

    // -------- Consulta SQL ----------

    // (1) somente telefone
    if (usePhone && cleanName === "") {
      const res = await this.pool.query(
        `SELECT * FROM users
       WHERE regexp_replace(coalesce(phone,''), '\\D', '', 'g') = $1
       LIMIT 1`,
        [cleanPhone],
      )
      // Se não encontrou no banco, tenta na memória
      const fallbackUser = searchInMemory()
      if (fallbackUser) return fallbackUser
      return res.rows[0]
    }

    // (2) somente nome  ➜ busca exata, senão tentativa por prefixo
    if (!usePhone) {
      // tentativa exata
      let res = await this.pool.query(
        `SELECT * FROM users
       WHERE unaccent(lower(trim(name))) = unaccent(lower(trim($1)))
       LIMIT 1`,
        [name],
      )
      if (res.rowCount > 0) {
        // Se não encontrou no banco, tenta na memória
        const fallbackUser = searchInMemory()
        if (fallbackUser) return fallbackUser
        return res.rows[0]
      }

      // tentativa por prefixo (João ↔ João Silva)
      res = await this.pool.query(
        `SELECT * FROM users
       WHERE unaccent(lower(name)) LIKE unaccent(lower($1)) || '%' 
       ORDER BY length(name)  -- traz o mais curto (normalmente o correto) primeiro
       LIMIT 1`,
        [name],
      )
      // Se não encontrou no banco, tenta na memória
      const fallbackUser = searchInMemory()
      if (fallbackUser) return fallbackUser
      return res.rows[0]
    }

    // (3) nome + telefone ➜ exato
    const res = await this.pool.query(
      `SELECT * FROM users
     WHERE unaccent(lower(trim(name))) = unaccent(lower(trim($1)))
       AND regexp_replace(coalesce(phone,''), '\\D', '', 'g') = $2
     LIMIT 1`,
      [name, cleanPhone],
    )
    // Se não encontrou no banco, tenta na memória
    const fallbackUser = searchInMemory()
    if (fallbackUser) return fallbackUser
    return res.rows[0]
  }

  async updateUser(id: string, updates: { name?: string; email?: string; phone?: string; role?: "admin" | "member" }) {
    if (!this.hasPool()) {
      const index = this.usersMemory.findIndex((user) => user.id === id)
      if (index === -1) return null

      const user = this.usersMemory[index]
      if (updates.name !== undefined) user.name = updates.name
      if (updates.email !== undefined) user.email = updates.email
      if (updates.phone !== undefined) user.phone = updates.phone
      if (updates.role !== undefined) user.role = updates.role
      user.updated_at = new Date()

      this.usersMemory[index] = user
      return user
    }

    const setClause: string[] = []
    const params: any[] = []
    let paramCount = 0

    if (updates.name !== undefined) {
      paramCount++
      setClause.push(`name = $${paramCount}`)
      params.push(updates.name)
    }
    if (updates.email !== undefined) {
      paramCount++
      setClause.push(`email = $${paramCount}`)
      params.push(updates.email)
    }
    if (updates.phone !== undefined) {
      paramCount++
      setClause.push(`phone = $${paramCount}`)
      params.push(updates.phone)
    }
    if (updates.role !== undefined) {
      paramCount++
      setClause.push(`role = $${paramCount}`)
      params.push(updates.role)
    }

    if (setClause.length === 0) {
      throw new Error("Nenhum campo para atualizar")
    }

    paramCount++
    params.push(id)

    const query = `
      UPDATE users 
      SET ${setClause.join(", ")}, updated_at = CURRENT_TIMESTAMP
      WHERE id = $${paramCount}
      RETURNING *
    `

    const result = await this.pool.query(query, params)
    return result.rows[0]
  }

  async deleteUser(id: string) {
    if (!this.hasPool()) {
      const index = this.usersMemory.findIndex((user) => user.id === id)
      if (index > -1) {
        const deleted = this.usersMemory.splice(index, 1)[0]
        return deleted
      }
      return null
    }

    const query = "DELETE FROM users WHERE id = $1 RETURNING *"
    const result = await this.pool.query(query, [id])
    return result.rows[0]
  }

  // Categories
  async createCategory(name: string, color: string, icon: string, familyId: string) {
    if (!this.hasPool()) {
      const category: Category = {
        id: crypto.randomUUID(),
        name,
        color,
        icon,
        familyId,
        created_at: new Date(),
        updated_at: new Date(),
      }
      this.categoriesMemory.push(category)
      return category
    }
    try {
      const query = `
        INSERT INTO categories (name, color, icon, family_id) 
        VALUES ($1, $2, $3, $4) 
        RETURNING *
      `
      const result = await this.pool.query(query, [name, color, icon, familyId])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao criar categoria:", error)
      throw new Error(`Erro ao criar categoria: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getCategoriesByFamilyId(familyId: string) {
    if (!this.hasPool()) {
      return this.categoriesMemory.filter((cat) => cat.familyId === familyId)
    }
    try {
      const query = "SELECT * FROM categories WHERE family_id = $1 ORDER BY name"
      const result = await this.pool.query(query, [familyId])
      return result.rows
    } catch (error) {
      console.error("Erro ao buscar categorias:", error)
      throw new Error(`Erro ao buscar categorias: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getCategoryById(id: string) {
    if (!this.hasPool()) {
      return this.categoriesMemory.find((cat) => cat.id === id) || null
    }
    try {
      const query = "SELECT * FROM categories WHERE id = $1"
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao buscar categoria:", error)
      throw new Error(`Erro ao buscar categoria: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async deleteCategory(id: string) {
    if (!this.hasPool()) {
      // Verificar se há despesas usando esta categoria
      const hasExpenses = this.expensesMemory.some((exp) => exp.categoryId === id)
      if (hasExpenses) {
        throw new Error("Não é possível deletar categoria que possui despesas associadas")
      }

      const index = this.categoriesMemory.findIndex((cat) => cat.id === id)
      if (index > -1) {
        const deleted = this.categoriesMemory.splice(index, 1)[0]
        return deleted
      }
      return null
    }
    try {
      // Verificar se há despesas usando esta categoria
      const expenseCheck = await this.pool.query("SELECT COUNT(*) FROM expenses WHERE category_id = $1", [id])
      if (Number.parseInt(expenseCheck.rows[0].count) > 0) {
        throw new Error("Não é possível deletar categoria que possui despesas associadas")
      }

      const query = "DELETE FROM categories WHERE id = $1 RETURNING *"
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao deletar categoria:", error)
      throw error // Re-throw para manter a mensagem específica
    }
  }

  // Expenses
  async createExpense(
    description: string,
    amount: number,
    categoryId: string,
    userId: string,
    familyId: string,
    expenseDate: Date,
  ) {
    if (!this.hasPool()) {
      const expense: Expense = {
        id: crypto.randomUUID(),
        description,
        amount,
        categoryId,
        userId,
        familyId,
        expenseDate,
        created_at: new Date(),
        updated_at: new Date(),
      }
      this.expensesMemory.push(expense)
      return expense
    }
    try {
      const query = `
        INSERT INTO expenses (description, amount, category_id, user_id, family_id, expense_date) 
        VALUES ($1, $2, $3, $4, $5, $6) 
        RETURNING *
      `
      const result = await this.pool.query(query, [description, amount, categoryId, userId, familyId, expenseDate])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao criar despesa:", error)
      throw new Error(`Erro ao criar despesa: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getExpensesByFamilyId(
    familyId: string,
    filters?: {
      categoryId?: string
      startDate?: Date
      endDate?: Date
      limit?: number
      offset?: number
    },
  ) {
    if (!this.hasPool()) {
      let expenses = this.expensesMemory.filter((exp) => exp.familyId === familyId)

      // Aplicar filtros
      if (filters?.categoryId) {
        expenses = expenses.filter((exp) => exp.categoryId === filters.categoryId)
      }
      if (filters?.startDate) {
        expenses = expenses.filter((exp) => exp.expenseDate >= filters.startDate!)
      }
      if (filters?.endDate) {
        expenses = expenses.filter((exp) => exp.expenseDate <= filters.endDate!)
      }

      // Ordenar por data
      expenses.sort((a, b) => b.expenseDate.getTime() - a.expenseDate.getTime())

      // Aplicar limit e offset
      if (filters?.offset) {
        expenses = expenses.slice(filters.offset)
      }
      if (filters?.limit) {
        expenses = expenses.slice(0, filters.limit)
      }

      // Enriquecer com dados de categoria e usuário
      return expenses.map((exp) => {
        const category = this.categoriesMemory.find((cat) => cat.id === exp.categoryId)
        const user = this.usersMemory.find((u) => u.id === exp.userId)
        return {
          ...exp,
          category_name: category?.name || "Categoria não encontrada",
          category_color: category?.color || "#999999",
          category_icon: category?.icon || "❓",
          user_name: user?.name || "Usuário não encontrado",
        }
      })
    }
    try {
      let query = `
        SELECT e.*, c.name as category_name, c.color as category_color, c.icon as category_icon,
               u.name as user_name
        FROM expenses e
        JOIN categories c ON e.category_id = c.id
        JOIN users u ON e.user_id = u.id
        WHERE e.family_id = $1
      `
      const params: any[] = [familyId]
      let paramCount = 1

      if (filters?.categoryId) {
        paramCount++
        query += ` AND e.category_id = $${paramCount}`
        params.push(filters.categoryId)
      }

      if (filters?.startDate) {
        paramCount++
        query += ` AND e.expense_date >= $${paramCount}`
        params.push(filters.startDate)
      }

      if (filters?.endDate) {
        paramCount++
        query += ` AND e.expense_date <= $${paramCount}`
        params.push(filters.endDate)
      }

      query += " ORDER BY e.expense_date DESC, e.created_at DESC"

      if (filters?.limit) {
        paramCount++
        query += ` LIMIT $${paramCount}`
        params.push(filters.limit)
      }

      if (filters?.offset) {
        paramCount++
        query += ` OFFSET $${paramCount}`
        params.push(filters.offset)
      }

      const result = await this.pool.query(query, params)
      return result.rows
    } catch (error) {
      console.error("Erro ao buscar despesas:", error)
      throw new Error(`Erro ao buscar despesas: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async getExpenseById(id: string) {
    if (!this.hasPool()) {
      const expense = this.expensesMemory.find((exp) => exp.id === id)
      if (!expense) return null

      const category = this.categoriesMemory.find((cat) => cat.id === expense.categoryId)
      const user = this.usersMemory.find((u) => u.id === expense.userId)

      return {
        ...expense,
        category_name: category?.name || "Categoria não encontrada",
        category_color: category?.color || "#999999",
        category_icon: category?.icon || "❓",
        user_name: user?.name || "Usuário não encontrado",
      }
    }
    try {
      const query = `
        SELECT e.*, c.name as category_name, c.color as category_color, c.icon as category_icon,
               u.name as user_name
        FROM expenses e
        JOIN categories c ON e.category_id = c.id
        JOIN users u ON e.user_id = u.id
        WHERE e.id = $1
      `
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao buscar despesa:", error)
      throw new Error(`Erro ao buscar despesa: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async updateExpense(
    id: string,
    updates: {
      description?: string
      amount?: number
      categoryId?: string
      expenseDate?: Date
    },
  ) {
    if (!this.hasPool()) {
      const index = this.expensesMemory.findIndex((exp) => exp.id === id)
      if (index === -1) return null

      const expense = this.expensesMemory[index]
      if (updates.description !== undefined) expense.description = updates.description
      if (updates.amount !== undefined) expense.amount = updates.amount
      if (updates.categoryId !== undefined) expense.categoryId = updates.categoryId
      if (updates.expenseDate !== undefined) expense.expenseDate = updates.expenseDate
      expense.updated_at = new Date()

      return expense
    }
    try {
      const setClause: string[] = []
      const params: any[] = []
      let paramCount = 0

      if (updates.description !== undefined) {
        paramCount++
        setClause.push(`description = $${paramCount}`)
        params.push(updates.description)
      }

      if (updates.amount !== undefined) {
        paramCount++
        setClause.push(`amount = $${paramCount}`)
        params.push(updates.amount)
      }

      if (updates.categoryId !== undefined) {
        paramCount++
        setClause.push(`category_id = $${paramCount}`)
        params.push(updates.categoryId)
      }

      if (updates.expenseDate !== undefined) {
        paramCount++
        setClause.push(`expense_date = $${paramCount}`)
        params.push(updates.expenseDate)
      }

      if (setClause.length === 0) {
        throw new Error("Nenhum campo para atualizar")
      }

      paramCount++
      params.push(id)

      const query = `
        UPDATE expenses 
        SET ${setClause.join(", ")}, updated_at = CURRENT_TIMESTAMP
        WHERE id = $${paramCount}
        RETURNING *
      `

      const result = await this.pool.query(query, params)
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao atualizar despesa:", error)
      throw new Error(`Erro ao atualizar despesa: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  async deleteExpense(id: string) {
    if (!this.hasPool()) {
      const index = this.expensesMemory.findIndex((exp) => exp.id === id)
      if (index > -1) {
        const deleted = this.expensesMemory.splice(index, 1)[0]
        return deleted
      }
      return null
    }
    try {
      const query = "DELETE FROM expenses WHERE id = $1 RETURNING *"
      const result = await this.pool.query(query, [id])
      return result.rows[0]
    } catch (error) {
      console.error("Erro ao deletar despesa:", error)
      throw new Error(`Erro ao deletar despesa: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  // Reports
  async getMonthlyReport(familyId: string, month: number, year: number) {
    if (!this.hasPool()) {
      // In-memory implementation (replace with your logic)
      return null
    }
    try {
      // Total de despesas do mês
      const totalQuery = `
        SELECT COALESCE(SUM(amount), 0) as total, COUNT(*) as count
        FROM expenses 
        WHERE family_id = $1 
          AND EXTRACT(MONTH FROM expense_date) = $2 
          AND EXTRACT(YEAR FROM expense_date) = $3
      `
      const totalResult = await this.pool.query(totalQuery, [familyId, month + 1, year])

      // Despesas por categoria
      const categoryQuery = `
        SELECT 
          c.id, c.name, c.color, c.icon,
          COALESCE(SUM(e.amount), 0) as total,
          COUNT(e.id) as expense_count
        FROM categories c
        LEFT JOIN expenses e ON c.id = e.category_id 
          AND e.family_id = $1
          AND EXTRACT(MONTH FROM e.expense_date) = $2 
          AND EXTRACT(YEAR FROM e.expense_date) = $3
        WHERE c.family_id = $1
        GROUP BY c.id, c.name, c.color, c.icon
        HAVING COALESCE(SUM(e.amount), 0) > 0
        ORDER BY total DESC
      `
      const categoryResult = await this.pool.query(categoryQuery, [familyId, month + 1, year])

      // Despesas recentes
      const recentQuery = `
        SELECT e.*, c.name as category_name, c.color as category_color, c.icon as category_icon,
               u.name as user_name
        FROM expenses e
        JOIN categories c ON e.category_id = c.id
        JOIN users u ON e.user_id = u.id
        WHERE e.family_id = $1 
          AND EXTRACT(MONTH FROM expense_date) = $2 
          AND EXTRACT(YEAR FROM expense_date) = $3
        ORDER BY e.expense_date DESC, e.created_at DESC
        LIMIT 10
      `
      const recentResult = await this.pool.query(recentQuery, [familyId, month + 1, year])

      // Despesas por dia
      const dailyQuery = `
        SELECT 
          EXTRACT(DAY FROM expense_date) as day,
          SUM(amount) as total,
          COUNT(*) as count
        FROM expenses 
        WHERE family_id = $1 
          AND EXTRACT(MONTH FROM expense_date) = $2 
          AND EXTRACT(YEAR FROM expense_date) = $3
        GROUP BY EXTRACT(DAY FROM expense_date)
        ORDER BY day
      `
      const dailyResult = await this.pool.query(dailyQuery, [familyId, month + 1, year])

      const totalAmount = Number.parseFloat(totalResult.rows[0].total)
      const totalExpenses = Number.parseInt(totalResult.rows[0].count)

      return {
        summary: {
          totalAmount,
          totalExpenses,
          averageExpense: totalExpenses > 0 ? totalAmount / totalExpenses : 0,
          categoriesUsed: categoryResult.rows.length,
        },
        expensesByCategory: categoryResult.rows.map((row) => ({
          category: {
            id: row.id,
            name: row.name,
            color: row.color,
            icon: row.icon,
          },
          total: Number.parseFloat(row.total),
          percentage: totalAmount > 0 ? (Number.parseFloat(row.total) / totalAmount) * 100 : 0,
          expenseCount: Number.parseInt(row.expense_count),
        })),
        recentExpenses: recentResult.rows.map((row) => ({
          id: row.id,
          description: row.description,
          amount: Number.parseFloat(row.amount),
          expense_date: row.expense_date,
          category: {
            name: row.category_name,
            color: row.category_color,
            icon: row.category_icon,
          },
          user_name: row.user_name,
        })),
        dailyExpenses: dailyResult.rows.map((row) => ({
          day: Number.parseInt(row.day),
          total: Number.parseFloat(row.total),
          count: Number.parseInt(row.count),
        })),
      }
    } catch (error) {
      console.error("Erro ao gerar relatório:", error)
      throw new Error(`Erro ao gerar relatório: ${error instanceof Error ? error.message : "Erro desconhecido"}`)
    }
  }

  // Método para testar conexão
  async testConnection() {
    if (!this.hasPool()) {
      return { success: PostgresDatabase.isDbReady }
    }
    try {
      const result = await this.pool.query("SELECT NOW() as timestamp")
      return { success: true, timestamp: result.rows[0].timestamp }
    } catch (error) {
      console.error("Erro de conexão:", error)
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" }
    }
  }

  // Método para fechar conexões (útil para testes)
  async close() {
    await this.pool.end()
  }
}

export const db = new PostgresDatabase()
