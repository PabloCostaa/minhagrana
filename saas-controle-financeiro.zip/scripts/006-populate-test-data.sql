-- Script para popular dados de teste adicionais

-- Inserir mais uma família de teste
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM families WHERE name = 'Família Santos') THEN
        INSERT INTO families (id, name) VALUES 
        ('550e8400-e29b-41d4-a716-446655440010', 'Família Santos');
        
        -- Inserir usuários para a família Santos
        INSERT INTO users (name, email, phone, family_id, role) VALUES 
        ('Maria Santos', 'maria@santos.com', '(11) 98888-8888', '550e8400-e29b-41d4-a716-446655440010', 'admin'),
        ('Pedro Santos', 'pedro@santos.com', '(11) 97777-7777', '550e8400-e29b-41d4-a716-446655440010', 'member');
        
        -- Inserir categorias para a família Santos
        INSERT INTO categories (name, color, icon, family_id) VALUES 
        ('Alimentação', '#FF6B6B', '🍽️', '550e8400-e29b-41d4-a716-446655440010'),
        ('Transporte', '#4ECDC4', '🚗', '550e8400-e29b-41d4-a716-446655440010'),
        ('Moradia', '#45B7D1', '🏠', '550e8400-e29b-41d4-a716-446655440010'),
        ('Saúde', '#96CEB4', '🏥', '550e8400-e29b-41d4-a716-446655440010'),
        ('Educação', '#FFEAA7', '📚', '550e8400-e29b-41d4-a716-446655440010'),
        ('Lazer', '#DDA0DD', '🎮', '550e8400-e29b-41d4-a716-446655440010');
    END IF;
END $$;

-- Inserir mais despesas de exemplo para a família Silva
DO $$
DECLARE
    user_id UUID;
    alimentacao_id UUID;
    transporte_id UUID;
    moradia_id UUID;
    saude_id UUID;
    lazer_id UUID;
BEGIN
    -- Buscar IDs necessários
    SELECT id INTO user_id FROM users WHERE email = 'joao@silva.com';
    SELECT id INTO alimentacao_id FROM categories WHERE name = 'Alimentação' AND family_id = '550e8400-e29b-41d4-a716-446655440000';
    SELECT id INTO transporte_id FROM categories WHERE name = 'Transporte' AND family_id = '550e8400-e29b-41d4-a716-446655440000';
    SELECT id INTO moradia_id FROM categories WHERE name = 'Moradia' AND family_id = '550e8400-e29b-41d4-a716-446655440000';
    SELECT id INTO saude_id FROM categories WHERE name = 'Saúde' AND family_id = '550e8400-e29b-41d4-a716-446655440000';
    SELECT id INTO lazer_id FROM categories WHERE name = 'Lazer' AND family_id = '550e8400-e29b-41d4-a716-446655440000';

    -- Inserir mais despesas variadas
    INSERT INTO expenses (description, amount, category_id, user_id, family_id, expense_date) VALUES 
    -- Alimentação
    ('Restaurante Japonês', 89.90, alimentacao_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '5 days'),
    ('Açougue Central', 45.60, alimentacao_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '6 days'),
    ('Feira Livre', 32.80, alimentacao_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '7 days'),
    ('iFood - Pizza', 55.90, alimentacao_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '8 days'),
    
    -- Transporte
    ('Estacionamento Shopping', 8.00, transporte_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '5 days'),
    ('Pedágio Rodovia', 12.70, transporte_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '9 days'),
    ('99 Pop', 15.30, transporte_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '10 days'),
    
    -- Moradia
    ('Conta de água', 85.40, moradia_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '12 days'),
    ('Internet Vivo', 99.90, moradia_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '15 days'),
    ('Condomínio', 350.00, moradia_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '20 days'),
    
    -- Saúde
    ('Consulta Médica', 180.00, saude_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '14 days'),
    ('Exame Laboratorial', 120.50, saude_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '18 days'),
    
    -- Lazer
    ('Netflix', 32.90, lazer_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '25 days'),
    ('Spotify', 21.90, lazer_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '25 days'),
    ('Academia', 89.90, lazer_id, user_id, '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '30 days');
    
END $$;

-- Mostrar resumo dos dados inseridos
SELECT 
    'Resumo dos Dados de Teste' as titulo,
    '' as detalhes
UNION ALL
SELECT 
    'Total de Famílias:',
    COUNT(*)::text
FROM families
UNION ALL
SELECT 
    'Total de Usuários:',
    COUNT(*)::text
FROM users
UNION ALL
SELECT 
    'Total de Categorias:',
    COUNT(*)::text
FROM categories
UNION ALL
SELECT 
    'Total de Despesas:',
    COUNT(*)::text
FROM expenses
UNION ALL
SELECT 
    'Valor Total das Despesas:',
    'R$ ' || TO_CHAR(SUM(amount), 'FM999G999D00')
FROM expenses;
