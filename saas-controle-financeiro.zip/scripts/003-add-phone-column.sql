-- Adicionar coluna de telefone na tabela users
ALTER TABLE users ADD COLUMN phone VARCHAR(20);

-- Criar índice para busca por telefone (opcional)
CREATE INDEX idx_users_phone ON users(phone);

-- Atualizar o usuário exemplo com um telefone
UPDATE users 
SET phone = '(11) 99999-9999' 
WHERE email = 'joao@silva.com';
