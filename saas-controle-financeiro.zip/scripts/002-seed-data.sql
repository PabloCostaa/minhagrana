-- Inserir família exemplo
INSERT INTO families (id, name) VALUES 
('550e8400-e29b-41d4-a716-446655440000', 'Família Silva');

-- Inserir usuário admin
INSERT INTO users (id, name, email, family_id, role) VALUES 
('550e8400-e29b-41d4-a716-446655440001', 'João Silva', 'joao@silva.com', '550e8400-e29b-41d4-a716-446655440000', 'admin');

-- Inserir categorias padrão
INSERT INTO categories (name, color, icon, family_id) VALUES 
('Alimentação', '#FF6B6B', '🍽️', '550e8400-e29b-41d4-a716-446655440000'),
('Transporte', '#4ECDC4', '🚗', '550e8400-e29b-41d4-a716-446655440000'),
('Moradia', '#45B7D1', '🏠', '550e8400-e29b-41d4-a716-446655440000'),
('Saúde', '#96CEB4', '🏥', '550e8400-e29b-41d4-a716-446655440000'),
('Educação', '#FFEAA7', '📚', '550e8400-e29b-41d4-a716-446655440000'),
('Lazer', '#DDA0DD', '🎮', '550e8400-e29b-41d4-a716-446655440000');

-- Inserir algumas despesas exemplo
INSERT INTO expenses (description, amount, category_id, user_id, family_id, expense_date) VALUES 
('Supermercado Pão de Açúcar', 245.80, (SELECT id FROM categories WHERE name = 'Alimentação' LIMIT 1), '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '2 days'),
('Combustível posto Shell', 120.00, (SELECT id FROM categories WHERE name = 'Transporte' LIMIT 1), '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '1 day'),
('Conta de luz', 180.50, (SELECT id FROM categories WHERE name = 'Moradia' LIMIT 1), '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE),
('Cinema shopping', 45.00, (SELECT id FROM categories WHERE name = 'Lazer' LIMIT 1), '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '3 days');
