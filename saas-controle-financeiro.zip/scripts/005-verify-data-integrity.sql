-- Script para verificar a integridade dos dados e relacionamentos

-- Verificar estrutura das tabelas
SELECT 
    table_name,
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns 
WHERE table_schema = 'public' 
    AND table_name IN ('families', 'users', 'categories', 'expenses')
ORDER BY table_name, ordinal_position;

-- Verificar relacionamentos (Foreign Keys)
SELECT
    tc.table_name, 
    kcu.column_name, 
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name 
FROM 
    information_schema.table_constraints AS tc 
    JOIN information_schema.key_column_usage AS kcu
      ON tc.constraint_name = kcu.constraint_name
      AND tc.table_schema = kcu.table_schema
    JOIN information_schema.constraint_column_usage AS ccu
      ON ccu.constraint_name = tc.constraint_name
      AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY' 
    AND tc.table_schema = 'public'
    AND tc.table_name IN ('users', 'categories', 'expenses');

-- Verificar índices criados
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE schemaname = 'public' 
    AND tablename IN ('families', 'users', 'categories', 'expenses')
ORDER BY tablename, indexname;

-- Verificar triggers
SELECT 
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers 
WHERE event_object_schema = 'public'
    AND event_object_table IN ('families', 'users', 'categories', 'expenses');

-- Verificar dados de exemplo
SELECT 
    f.name as familia,
    COUNT(DISTINCT u.id) as total_usuarios,
    COUNT(DISTINCT c.id) as total_categorias,
    COUNT(DISTINCT e.id) as total_despesas,
    COALESCE(SUM(e.amount), 0) as total_gasto
FROM families f
LEFT JOIN users u ON f.id = u.family_id
LEFT JOIN categories c ON f.id = c.family_id
LEFT JOIN expenses e ON f.id = e.family_id
GROUP BY f.id, f.name
ORDER BY f.name;

-- Verificar despesas por categoria
SELECT 
    c.name as categoria,
    c.icon,
    c.color,
    COUNT(e.id) as total_despesas,
    COALESCE(SUM(e.amount), 0) as total_valor,
    COALESCE(AVG(e.amount), 0) as valor_medio
FROM categories c
LEFT JOIN expenses e ON c.id = e.category_id
WHERE c.family_id = '550e8400-e29b-41d4-a716-446655440000'
GROUP BY c.id, c.name, c.icon, c.color
ORDER BY total_valor DESC;

-- Verificar despesas recentes
SELECT 
    e.description,
    e.amount,
    e.expense_date,
    c.name as categoria,
    c.icon,
    u.name as usuario
FROM expenses e
JOIN categories c ON e.category_id = c.id
JOIN users u ON e.user_id = u.id
WHERE e.family_id = '550e8400-e29b-41d4-a716-446655440000'
ORDER BY e.expense_date DESC, e.created_at DESC
LIMIT 10;
