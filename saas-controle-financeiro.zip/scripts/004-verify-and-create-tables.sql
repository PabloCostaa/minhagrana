-- Verificar e criar todas as tabelas necessárias para o sistema de despesas

-- Criar extensão para UUID se não existir
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de famílias (verificar se existe)
CREATE TABLE IF NOT EXISTS families (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de usuários (verificar se existe e adicionar coluna phone se necessário)
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'member')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Adicionar coluna phone se não existir
DO $$ 
BEGIN 
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name = 'users' AND column_name = 'phone') THEN
        ALTER TABLE users ADD COLUMN phone VARCHAR(20);
    END IF;
END $$;

-- Tabela de categorias (verificar se existe)
CREATE TABLE IF NOT EXISTS categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    color VARCHAR(7) NOT NULL, -- Hex color code
    icon VARCHAR(10) NOT NULL, -- Emoji icon
    family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(name, family_id)
);

-- Tabela de despesas (verificar se existe)
CREATE TABLE IF NOT EXISTS expenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    description VARCHAR(500) NOT NULL,
    amount DECIMAL(10,2) NOT NULL CHECK (amount > 0),
    category_id UUID NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    family_id UUID NOT NULL REFERENCES families(id) ON DELETE CASCADE,
    expense_date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Criar índices se não existirem
CREATE INDEX IF NOT EXISTS idx_users_family_id ON users(family_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_categories_family_id ON categories(family_id);
CREATE INDEX IF NOT EXISTS idx_expenses_family_id ON expenses(family_id);
CREATE INDEX IF NOT EXISTS idx_expenses_category_id ON expenses(category_id);
CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_expenses_family_date ON expenses(family_id, expense_date);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Criar triggers se não existirem
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_families_updated_at') THEN
        CREATE TRIGGER update_families_updated_at BEFORE UPDATE ON families
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at') THEN
        CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_categories_updated_at') THEN
        CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_expenses_updated_at') THEN
        CREATE TRIGGER update_expenses_updated_at BEFORE UPDATE ON expenses
            FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
    END IF;
END $$;

-- Verificar se existem dados de exemplo, se não, inserir
DO $$
BEGIN
    -- Inserir família exemplo se não existir
    IF NOT EXISTS (SELECT 1 FROM families WHERE name = 'Família Silva') THEN
        INSERT INTO families (id, name) VALUES 
        ('550e8400-e29b-41d4-a716-446655440000', 'Família Silva');
    END IF;

    -- Inserir usuário admin se não existir
    IF NOT EXISTS (SELECT 1 FROM users WHERE email = 'joao@silva.com') THEN
        INSERT INTO users (id, name, email, phone, family_id, role) VALUES 
        ('550e8400-e29b-41d4-a716-446655440001', 'João Silva', 'joao@silva.com', '(11) 99999-9999', '550e8400-e29b-41d4-a716-446655440000', 'admin');
    END IF;

    -- Inserir categorias padrão se não existirem
    IF NOT EXISTS (SELECT 1 FROM categories WHERE family_id = '550e8400-e29b-41d4-a716-446655440000') THEN
        INSERT INTO categories (name, color, icon, family_id) VALUES 
        ('Alimentação', '#FF6B6B', '🍽️', '550e8400-e29b-41d4-a716-446655440000'),
        ('Transporte', '#4ECDC4', '🚗', '550e8400-e29b-41d4-a716-446655440000'),
        ('Moradia', '#45B7D1', '🏠', '550e8400-e29b-41d4-a716-446655440000'),
        ('Saúde', '#96CEB4', '🏥', '550e8400-e29b-41d4-a716-446655440000'),
        ('Educação', '#FFEAA7', '📚', '550e8400-e29b-41d4-a716-446655440000'),
        ('Lazer', '#DDA0DD', '🎮', '550e8400-e29b-41d4-a716-446655440000');
    END IF;
END $$;

-- Inserir algumas despesas exemplo se não existirem
DO $$
DECLARE
    alimentacao_id UUID;
    transporte_id UUID;
    moradia_id UUID;
    lazer_id UUID;
BEGIN
    -- Buscar IDs das categorias
    SELECT id INTO alimentacao_id FROM categories WHERE name = 'Alimentação' AND family_id = '550e8400-e29b-41d4-a716-446655440000' LIMIT 1;
    SELECT id INTO transporte_id FROM categories WHERE name = 'Transporte' AND family_id = '550e8400-e29b-41d4-a716-446655440000' LIMIT 1;
    SELECT id INTO moradia_id FROM categories WHERE name = 'Moradia' AND family_id = '550e8400-e29b-41d4-a716-446655440000' LIMIT 1;
    SELECT id INTO lazer_id FROM categories WHERE name = 'Lazer' AND family_id = '550e8400-e29b-41d4-a716-446655440000' LIMIT 1;

    -- Inserir despesas exemplo se não existirem
    IF NOT EXISTS (SELECT 1 FROM expenses WHERE family_id = '550e8400-e29b-41d4-a716-446655440000') THEN
        INSERT INTO expenses (description, amount, category_id, user_id, family_id, expense_date) VALUES 
        ('Supermercado Pão de Açúcar', 245.80, alimentacao_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '2 days'),
        ('Combustível Posto Shell', 120.00, transporte_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '1 day'),
        ('Conta de luz CEMIG', 180.50, moradia_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE),
        ('Cinema Shopping Center', 45.00, lazer_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '3 days'),
        ('Padaria do Bairro', 25.50, alimentacao_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '1 day'),
        ('Uber para trabalho', 18.90, transporte_id, '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE),
        ('Farmácia Drogasil', 67.30, (SELECT id FROM categories WHERE name = 'Saúde' AND family_id = '550e8400-e29b-41d4-a716-446655440000' LIMIT 1), '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', CURRENT_DATE - INTERVAL '4 days');
    END IF;
END $$;

-- Mostrar estatísticas das tabelas criadas
SELECT 
    'families' as tabela,
    COUNT(*) as total_registros
FROM families
UNION ALL
SELECT 
    'users' as tabela,
    COUNT(*) as total_registros
FROM users
UNION ALL
SELECT 
    'categories' as tabela,
    COUNT(*) as total_registros
FROM categories
UNION ALL
SELECT 
    'expenses' as tabela,
    COUNT(*) as total_registros
FROM expenses
ORDER BY tabela;
