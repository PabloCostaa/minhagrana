-- Script para backup e restore dos dados

-- Função para fazer backup dos dados em formato INSERT
CREATE OR REPLACE FUNCTION backup_data()
RETURNS TEXT AS $$
DECLARE
    backup_sql TEXT := '';
BEGIN
    -- Backup das famílias
    backup_sql := backup_sql || E'\n-- Backup das Famílias\n';
    SELECT string_agg(
        'INSERT INTO families (id, name, created_at, updated_at) VALUES (' ||
        quote_literal(id::text) || ', ' ||
        quote_literal(name) || ', ' ||
        quote_literal(created_at::text) || ', ' ||
        quote_literal(updated_at::text) || ');',
        E'\n'
    ) INTO backup_sql
    FROM families;
    
    -- Backup dos usuários
    backup_sql := backup_sql || E'\n\n-- Backup dos Usuários\n';
    SELECT backup_sql || string_agg(
        'INSERT INTO users (id, name, email, phone, family_id, role, created_at, updated_at) VALUES (' ||
        quote_literal(id::text) || ', ' ||
        quote_literal(name) || ', ' ||
        quote_literal(email) || ', ' ||
        COALESCE(quote_literal(phone), 'NULL') || ', ' ||
        quote_literal(family_id::text) || ', ' ||
        quote_literal(role) || ', ' ||
        quote_literal(created_at::text) || ', ' ||
        quote_literal(updated_at::text) || ');',
        E'\n'
    ) INTO backup_sql
    FROM users;
    
    -- Backup das categorias
    backup_sql := backup_sql || E'\n\n-- Backup das Categorias\n';
    SELECT backup_sql || string_agg(
        'INSERT INTO categories (id, name, color, icon, family_id, created_at, updated_at) VALUES (' ||
        quote_literal(id::text) || ', ' ||
        quote_literal(name) || ', ' ||
        quote_literal(color) || ', ' ||
        quote_literal(icon) || ', ' ||
        quote_literal(family_id::text) || ', ' ||
        quote_literal(created_at::text) || ', ' ||
        quote_literal(updated_at::text) || ');',
        E'\n'
    ) INTO backup_sql
    FROM categories;
    
    -- Backup das despesas
    backup_sql := backup_sql || E'\n\n-- Backup das Despesas\n';
    SELECT backup_sql || string_agg(
        'INSERT INTO expenses (id, description, amount, category_id, user_id, family_id, expense_date, created_at, updated_at) VALUES (' ||
        quote_literal(id::text) || ', ' ||
        quote_literal(description) || ', ' ||
        amount::text || ', ' ||
        quote_literal(category_id::text) || ', ' ||
        quote_literal(user_id::text) || ', ' ||
        quote_literal(family_id::text) || ', ' ||
        quote_literal(expense_date::text) || ', ' ||
        quote_literal(created_at::text) || ', ' ||
        quote_literal(updated_at::text) || ');',
        E'\n'
    ) INTO backup_sql
    FROM expenses;
    
    RETURN backup_sql;
END;
$$ LANGUAGE plpgsql;

-- Para usar o backup, execute:
-- SELECT backup_data();

-- Função para limpar todas as tabelas (cuidado!)
CREATE OR REPLACE FUNCTION clean_all_data()
RETURNS TEXT AS $$
BEGIN
    DELETE FROM expenses;
    DELETE FROM categories;
    DELETE FROM users;
    DELETE FROM families;
    
    RETURN 'Todos os dados foram removidos!';
END;
$$ LANGUAGE plpgsql;

-- Para limpar dados (USE COM CUIDADO!):
-- SELECT clean_all_data();
