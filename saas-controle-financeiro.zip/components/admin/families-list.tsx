"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Users, Calendar, Mail, Crown, Plus, Phone, ChevronDown, ChevronUp, Edit, Trash2 } from "lucide-react"
import { AddUserForm } from "./add-user-form"
import { EditUserForm } from "./edit-user-form"
import type { Family, User } from "@/types"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface FamilyWithUsers extends Family {
  users: User[]
}

interface FamiliesListProps {
  families: FamilyWithUsers[]
  onUserAdded: (familyId: string, user: User) => void
  onUserUpdated: (updatedUser: User) => void
  onUserDeleted: (userId: string, familyId: string, userName: string) => void
}

export function FamiliesList({ families, onUserAdded, onUserUpdated, onUserDeleted }: FamiliesListProps) {
  const [selectedFamily, setSelectedFamily] = useState<string | null>(null)
  const [expandedFamilies, setExpandedFamilies] = useState<Set<string>>(new Set())
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [actionState, setActionState] = useState<{ loading: boolean; error: string | null }>({
    loading: false,
    error: null,
  })

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString("pt-BR")
  }

  const getRoleBadge = (role: string) => {
    return role === "admin" ? (
      <Badge variant="default" className="flex items-center gap-1 text-xs">
        <Crown className="h-3 w-3" />
        <span className="hidden sm:inline">Admin</span>
        <span className="sm:hidden">A</span>
      </Badge>
    ) : (
      <Badge variant="secondary" className="flex items-center gap-1 text-xs">
        <Users className="h-3 w-3" />
        <span className="hidden sm:inline">Membro</span>
        <span className="sm:hidden">M</span>
      </Badge>
    )
  }

  const toggleFamilyExpansion = (familyId: string) => {
    const newExpanded = new Set(expandedFamilies)
    if (newExpanded.has(familyId)) {
      newExpanded.delete(familyId)
    } else {
      newExpanded.add(familyId)
    }
    setExpandedFamilies(newExpanded)
  }

  const handleEditClick = (user: User) => {
    setActionState({ loading: false, error: null })
    setEditingUser(user)
  }

  const handleDeleteClick = async (user: User, familyId: string) => {
    if (!window.confirm(`Tem certeza que deseja excluir o usuário "${user.name}"? Esta ação não pode ser desfeita.`)) {
      return
    }

    setActionState({ loading: true, error: null })
    try {
      const response = await fetch(`/api/users/${user.id}`, { method: "DELETE" })
      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao excluir usuário")
      }

      onUserDeleted(user.id, familyId, user.name)
    } catch (err) {
      setActionState({ loading: false, error: err instanceof Error ? err.message : "Erro desconhecido" })
    } finally {
      setActionState((prev) => ({ ...prev, loading: false }))
    }
  }

  const handleUserUpdated = (updatedUser: User) => {
    onUserUpdated(updatedUser)
    setEditingUser(null)
  }

  if (families.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-8 sm:py-12">
          <Users className="h-8 w-8 sm:h-12 sm:w-12 text-muted-foreground mb-4" />
          <h3 className="text-base sm:text-lg font-semibold mb-2">Nenhuma família cadastrada</h3>
          <p className="text-sm text-muted-foreground text-center px-4">
            Comece criando sua primeira família usando o formulário acima.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <Dialog open={!!editingUser} onOpenChange={(isOpen) => !isOpen && setEditingUser(null)}>
        <DialogContent className="sm:max-w-[625px]">
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
            <DialogDescription>
              Altere os dados do usuário. Clique em salvar para aplicar as mudanças.
            </DialogDescription>
          </DialogHeader>
          {editingUser && (
            <EditUserForm user={editingUser} onSuccess={handleUserUpdated} onCancel={() => setEditingUser(null)} />
          )}
        </DialogContent>
      </Dialog>

      {actionState.error && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>{actionState.error}</AlertDescription>
        </Alert>
      )}

      {families.map((family) => {
        const isExpanded = expandedFamilies.has(family.id)
        return (
          <Card key={family.id} className="w-full">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Users className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                    <span className="truncate">{family.name}</span>
                  </CardTitle>
                  <CardDescription className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mt-2 text-xs sm:text-sm">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3 sm:h-4 sm:w-4" />
                      {formatDate(family.created_at)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3 sm:h-4 sm:w-4" />
                      {family.users.length} {family.users.length === 1 ? "membro" : "membros"}
                    </span>
                  </CardDescription>
                </div>
                <div className="flex flex-col sm:flex-row gap-2 ml-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleFamilyExpansion(family.id)}
                    className="h-8 px-2 sm:px-3"
                  >
                    {isExpanded ? (
                      <ChevronUp className="h-3 w-3 sm:h-4 sm:w-4" />
                    ) : (
                      <ChevronDown className="h-3 w-3 sm:h-4 sm:w-4" />
                    )}
                    <span className="hidden sm:inline ml-1">{isExpanded ? "Ocultar" : "Ver"}</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setSelectedFamily(selectedFamily === family.id ? null : family.id)}
                    className="h-8 px-2 sm:px-3"
                  >
                    <Plus className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline ml-1">Adicionar</span>
                  </Button>
                </div>
              </div>
            </CardHeader>

            {isExpanded && (
              <CardContent className="pt-0">
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-3 text-sm sm:text-base">Membros da Família</h4>
                    <div className="hidden sm:block">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="text-xs">Nome</TableHead>
                            <TableHead className="text-xs">Contato</TableHead>
                            <TableHead className="text-xs">Função</TableHead>
                            <TableHead className="text-xs">Data</TableHead>
                            <TableHead className="text-right text-xs">Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {family.users.map((user) => (
                            <TableRow key={user.id}>
                              <TableCell className="font-medium text-sm">{user.name}</TableCell>
                              <TableCell className="text-sm">
                                <div className="flex flex-col gap-1">
                                  <div className="flex items-center gap-2">
                                    <Mail className="h-3 w-3 text-muted-foreground" />
                                    <span className="truncate">{user.email}</span>
                                  </div>
                                  {user.phone && (
                                    <div className="flex items-center gap-2">
                                      <Phone className="h-3 w-3 text-muted-foreground" />
                                      {user.phone}
                                    </div>
                                  )}
                                </div>
                              </TableCell>
                              <TableCell>{getRoleBadge(user.role)}</TableCell>
                              <TableCell className="text-sm">{formatDate(user.created_at)}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex items-center justify-end gap-1">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => handleEditClick(user)}
                                  >
                                    <Edit className="h-4 w-4" />
                                    <span className="sr-only">Editar</span>
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 text-red-500 hover:text-red-600"
                                    onClick={() => handleDeleteClick(user, family.id)}
                                    disabled={actionState.loading}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">Excluir</span>
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                    <div className="sm:hidden space-y-3">
                      {family.users.map((user) => (
                        <Card key={user.id} className="p-3">
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h5 className="font-medium text-sm">{user.name}</h5>
                              {getRoleBadge(user.role)}
                            </div>
                            <div className="space-y-1 text-xs text-muted-foreground">
                              <div className="flex items-center gap-2">
                                <Mail className="h-3 w-3" />
                                <span className="truncate">{user.email}</span>
                              </div>
                              {user.phone && (
                                <div className="flex items-center gap-2">
                                  <Phone className="h-3 w-3" />
                                  {user.phone}
                                </div>
                              )}
                              <div className="flex items-center gap-2">
                                <Calendar className="h-3 w-3" />
                                {formatDate(user.created_at)}
                              </div>
                            </div>
                            <div className="flex items-center justify-end gap-2 border-t mt-3 pt-3">
                              <Button variant="outline" size="sm" onClick={() => handleEditClick(user)}>
                                <Edit className="h-4 w-4 mr-1" /> Editar
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-red-500 hover:text-red-600 bg-transparent"
                                onClick={() => handleDeleteClick(user, family.id)}
                                disabled={actionState.loading}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Excluir
                              </Button>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                  {selectedFamily === family.id && (
                    <div className="border-t pt-4">
                      <AddUserForm
                        familyId={family.id}
                        familyName={family.name}
                        onSuccess={(user) => {
                          onUserAdded(family.id, user)
                          setSelectedFamily(null)
                        }}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            )}
          </Card>
        )
      })}
    </div>
  )
}
