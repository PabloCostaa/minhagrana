"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, Users, CheckCircle } from "lucide-react"

interface CreateFamilyFormProps {
  onSuccess: (family: any) => void
}

export function CreateFamilyForm({ onSuccess }: CreateFamilyFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    adminName: "",
    adminEmail: "",
    adminPhone: "",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      console.log("Enviando dados:", formData)

      const response = await fetch("/api/families", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(formData),
      })

      console.log("Status da resposta:", response.status)
      console.log("Headers da resposta:", response.headers)

      // --- read body once ----------------------------------------------------
      const raw = await response.text()
      let data: any
      try {
        data = JSON.parse(raw)
      } catch {
        data = { error: raw } // plain-text fallback
      }

      if (!response.ok) {
        throw new Error(data.error || `Erro HTTP ${response.status}`)
      }

      // Sucesso
      setSuccess(`Família "${formData.name}" criada com sucesso!`)
      // data.data contém { family, admin }
      onSuccess(data.data)

      // Limpar formulário
      setFormData({
        name: "",
        adminName: "",
        adminEmail: "",
        adminPhone: "",
      })

      // Limpar mensagem de sucesso após 5 segundos
      setTimeout(() => setSuccess(null), 5000)
    } catch (err) {
      console.error("Erro no formulário:", err)

      if (err instanceof Error) {
        if (err.message.includes("Failed to fetch")) {
          setError("Erro de conexão. Verifique sua internet e tente novamente.")
        } else if (err.message.includes("JSON")) {
          setError("Erro de comunicação com o servidor. Tente novamente.")
        } else {
          setError(err.message)
        }
      } else {
        setError("Erro desconhecido. Tente novamente.")
      }
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Limpar mensagens ao digitar
    if (error) setError(null)
    if (success) setSuccess(null)
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Users className="h-4 w-4 sm:h-5 sm:w-5" />
          <span className="hidden sm:inline">Criar Nova Família</span>
          <span className="sm:hidden">Nova Família</span>
        </CardTitle>
        <CardDescription className="text-sm">Cadastre uma nova família e defina o administrador</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription className="text-sm">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800 text-sm">{success}</AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="familyName" className="text-sm font-medium">
              Nome da Família *
            </Label>
            <Input
              id="familyName"
              placeholder="Ex: Família Silva"
              value={formData.name}
              onChange={(e) => handleChange("name", e.target.value)}
              required
              disabled={loading}
              className="h-10"
            />
          </div>

          {/* Grid responsivo para campos do admin */}
          <div className="space-y-4 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="adminName" className="text-sm font-medium">
                Nome do Admin *
              </Label>
              <Input
                id="adminName"
                placeholder="Ex: João Silva"
                value={formData.adminName}
                onChange={(e) => handleChange("adminName", e.target.value)}
                required
                disabled={loading}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="adminEmail" className="text-sm font-medium">
                Email do Admin *
              </Label>
              <Input
                id="adminEmail"
                type="email"
                placeholder="joao@silva.com"
                value={formData.adminEmail}
                onChange={(e) => handleChange("adminEmail", e.target.value)}
                required
                disabled={loading}
                className="h-10"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="adminPhone" className="text-sm font-medium">
              Telefone do Admin
            </Label>
            <Input
              id="adminPhone"
              type="tel"
              placeholder="(11) 99999-9999"
              value={formData.adminPhone}
              onChange={(e) => handleChange("adminPhone", e.target.value)}
              disabled={loading}
              className="h-10"
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full h-10">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {loading ? "Criando..." : "Criar Família"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
