"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, UserPlus } from "lucide-react"

interface AddUserFormProps {
  familyId: string
  familyName: string
  onSuccess: (user: any) => void
}

export function AddUserForm({ familyId, familyName, onSuccess }: AddUserFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    role: "member" as "admin" | "member",
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)

    try {
      // Simular adição de usuário - em implementação real, usar endpoint da API
      await new Promise((resolve) => setTimeout(resolve, 1000))

      const newUser = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData,
        familyId,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      onSuccess(newUser)

      // Limpar formulário
      setFormData({
        name: "",
        email: "",
        phone: "",
        role: "member",
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro desconhecido")
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
          <UserPlus className="h-4 w-4 sm:h-5 sm:w-5" />
          <span className="hidden sm:inline">Adicionar Membro</span>
          <span className="sm:hidden">Novo Membro</span>
        </CardTitle>
        <CardDescription className="text-sm">Adicionar à família "{familyName}"</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription className="text-sm">{error}</AlertDescription>
            </Alert>
          )}

          {/* Grid responsivo */}
          <div className="space-y-4 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="userName" className="text-sm font-medium">
                Nome Completo *
              </Label>
              <Input
                id="userName"
                placeholder="Ex: Maria Silva"
                value={formData.name}
                onChange={(e) => handleChange("name", e.target.value)}
                required
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="userEmail" className="text-sm font-medium">
                Email *
              </Label>
              <Input
                id="userEmail"
                type="email"
                placeholder="maria@silva.com"
                value={formData.email}
                onChange={(e) => handleChange("email", e.target.value)}
                required
                className="h-10"
              />
            </div>
          </div>

          <div className="space-y-4 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-4">
            <div className="space-y-2">
              <Label htmlFor="userPhone" className="text-sm font-medium">
                Telefone
              </Label>
              <Input
                id="userPhone"
                type="tel"
                placeholder="(11) 99999-9999"
                value={formData.phone}
                onChange={(e) => handleChange("phone", e.target.value)}
                className="h-10"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="userRole" className="text-sm font-medium">
                Função *
              </Label>
              <Select value={formData.role} onValueChange={(value) => handleChange("role", value)}>
                <SelectTrigger className="h-10">
                  <SelectValue placeholder="Selecione a função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="member">Membro</SelectItem>
                  <SelectItem value="admin">Administrador</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full h-10">
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {loading ? "Adicionando..." : "Adicionar Membro"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
