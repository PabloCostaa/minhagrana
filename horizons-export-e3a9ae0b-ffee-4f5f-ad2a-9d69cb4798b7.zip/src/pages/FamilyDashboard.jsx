
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Users, DollarSign, TrendingUp, Calendar, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const FamilyDashboard = () => {
  const { familyId } = useParams();
  const [family, setFamily] = useState(null);
  const [expenses, setExpenses] = useState([]);

  useEffect(() => {
    // Load family data
    const savedFamilies = localStorage.getItem('families');
    if (savedFamilies) {
      const families = JSON.parse(savedFamilies);
      const currentFamily = families.find(f => f.id === parseInt(familyId));
      setFamily(currentFamily);
    }

    // Load expenses for this family
    const savedExpenses = localStorage.getItem('expenses');
    if (savedExpenses) {
      const allExpenses = JSON.parse(savedExpenses);
      const familyExpenses = allExpenses.filter(e => e.familyId === familyId);
      setExpenses(familyExpenses);
    }
  }, [familyId]);

  if (!family) {
    return (
      <div className="min-h-screen p-6 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Família não encontrada</h2>
          <Link to="/admin">
            <Button className="btn-gradient">Voltar ao Admin</Button>
          </Link>
        </div>
      </div>
    );
  }

  const remainingBudget = family.budget - family.expenses;
  const budgetPercentage = (family.expenses / family.budget) * 100;

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to="/admin">
            <Button variant="outline" size="icon" className="glass-effect">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-bold gradient-text">{family.name}</h1>
            <p className="text-gray-300">Dashboard financeiro da família</p>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <Card className="expense-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Membros</p>
                  <p className="text-2xl font-bold text-white">{family.members}</p>
                </div>
                <Users className="h-8 w-8 text-blue-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="expense-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Orçamento</p>
                  <p className="text-2xl font-bold text-green-400">R$ {family.budget.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="expense-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Gastos</p>
                  <p className="text-2xl font-bold text-red-400">R$ {family.expenses.toLocaleString()}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="expense-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">Restante</p>
                  <p className={`text-2xl font-bold ${remainingBudget >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    R$ {remainingBudget.toLocaleString()}
                  </p>
                </div>
                <DollarSign className={`h-8 w-8 ${remainingBudget >= 0 ? 'text-green-400' : 'text-red-400'}`} />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Budget Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-8"
        >
          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="text-white">Progresso do Orçamento</CardTitle>
              <CardDescription className="text-gray-300">
                {budgetPercentage.toFixed(1)}% do orçamento utilizado
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="w-full bg-gray-700 rounded-full h-4">
                <div 
                  className={`h-4 rounded-full transition-all duration-500 ${
                    budgetPercentage > 100 ? 'bg-red-500' : 
                    budgetPercentage > 80 ? 'bg-yellow-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${Math.min(budgetPercentage, 100)}%` }}
                ></div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Expenses */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="text-white">Despesas Recentes</CardTitle>
              <CardDescription className="text-gray-300">
                Últimas movimentações da família
              </CardDescription>
            </CardHeader>
            <CardContent>
              {expenses.length > 0 ? (
                <div className="space-y-4">
                  {expenses.slice(-5).reverse().map((expense, index) => (
                    <motion.div
                      key={expense.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.7 + index * 0.1 }}
                      className="flex items-center justify-between p-4 glass-effect rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <Tag className="h-5 w-5 text-blue-400" />
                        <div>
                          <p className="text-white font-medium">{expense.description}</p>
                          <p className="text-gray-400 text-sm flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(expense.date).toLocaleDateString('pt-BR')} • {expense.category}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-red-400 font-bold">-R$ {expense.amount.toLocaleString()}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">Nenhuma despesa cadastrada ainda</p>
                  <Link to="/expenses" className="inline-block mt-4">
                    <Button className="btn-gradient">Cadastrar Primeira Despesa</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default FamilyDashboard;
