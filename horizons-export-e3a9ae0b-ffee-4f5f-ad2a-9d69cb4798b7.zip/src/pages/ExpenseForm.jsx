
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, DollarSign, Calendar, Tag, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { toast } from '@/components/ui/use-toast';

const ExpenseForm = () => {
  const [families, setFamilies] = useState([]);
  const [expense, setExpense] = useState({
    familyId: '',
    description: '',
    amount: '',
    category: '',
    date: new Date().toISOString().split('T')[0]
  });

  const categories = [
    'Alimentação',
    'Transporte',
    'Moradia',
    'Saúde',
    'Educação',
    'Lazer',
    'Vestuário',
    'Outros'
  ];

  useEffect(() => {
    const savedFamilies = localStorage.getItem('families');
    if (savedFamilies) {
      setFamilies(JSON.parse(savedFamilies));
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!expense.familyId || !expense.description || !expense.amount || !expense.category) {
      toast({
        title: 'Erro',
        description: 'Todos os campos são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    // Save expense
    const expenses = JSON.parse(localStorage.getItem('expenses') || '[]');
    const newExpense = {
      id: Date.now(),
      ...expense,
      amount: parseFloat(expense.amount),
      createdAt: new Date().toISOString()
    };
    
    expenses.push(newExpense);
    localStorage.setItem('expenses', JSON.stringify(expenses));

    // Update family expenses
    const updatedFamilies = families.map(family => {
      if (family.id === parseInt(expense.familyId)) {
        return {
          ...family,
          expenses: family.expenses + parseFloat(expense.amount)
        };
      }
      return family;
    });
    
    setFamilies(updatedFamilies);
    localStorage.setItem('families', JSON.stringify(updatedFamilies));

    // Reset form
    setExpense({
      familyId: '',
      description: '',
      amount: '',
      category: '',
      date: new Date().toISOString().split('T')[0]
    });

    toast({
      title: 'Sucesso!',
      description: 'Despesa cadastrada com sucesso!'
    });
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8"
        >
          <Link to="/">
            <Button variant="outline" size="icon" className="glass-effect">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-4xl font-bold gradient-text">Cadastrar Despesa</h1>
            <p className="text-gray-300">Registre uma nova despesa familiar</p>
          </div>
        </motion.div>

        {/* Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <DollarSign className="h-6 w-6 text-green-400" />
                Nova Despesa
              </CardTitle>
              <CardDescription className="text-gray-300">
                Preencha os dados da despesa para registro no sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="family" className="text-white flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Família
                  </Label>
                  <Select
                    id="family"
                    value={expense.familyId}
                    onChange={(e) => setExpense({...expense, familyId: e.target.value})}
                    className="glass-effect input-glow text-white"
                  >
                    <option value="">Selecione uma família</option>
                    {families.map(family => (
                      <option key={family.id} value={family.id}>
                        {family.name}
                      </option>
                    ))}
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description" className="text-white">Descrição</Label>
                  <Input
                    id="description"
                    value={expense.description}
                    onChange={(e) => setExpense({...expense, description: e.target.value})}
                    placeholder="Ex: Compras do supermercado"
                    className="glass-effect input-glow text-white"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="amount" className="text-white flex items-center gap-2">
                      <DollarSign className="h-4 w-4" />
                      Valor (R$)
                    </Label>
                    <Input
                      id="amount"
                      type="number"
                      step="0.01"
                      value={expense.amount}
                      onChange={(e) => setExpense({...expense, amount: e.target.value})}
                      placeholder="0.00"
                      className="glass-effect input-glow text-white"
                    />
                  </div>

                  <div>
                    <Label htmlFor="date" className="text-white flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Data
                    </Label>
                    <Input
                      id="date"
                      type="date"
                      value={expense.date}
                      onChange={(e) => setExpense({...expense, date: e.target.value})}
                      className="glass-effect input-glow text-white"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="category" className="text-white flex items-center gap-2">
                    <Tag className="h-4 w-4" />
                    Categoria
                  </Label>
                  <Select
                    id="category"
                    value={expense.category}
                    onChange={(e) => setExpense({...expense, category: e.target.value})}
                    className="glass-effect input-glow text-white"
                  >
                    <option value="">Selecione uma categoria</option>
                    {categories.map(category => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </Select>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button type="submit" className="flex-1 btn-gradient">
                    Cadastrar Despesa
                  </Button>
                  <Link to="/" className="flex-1">
                    <Button type="button" variant="outline" className="w-full glass-effect">
                      Cancelar
                    </Button>
                  </Link>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>

        {/* Recent Expenses Preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8"
        >
          <Card className="expense-card">
            <CardHeader>
              <CardTitle className="text-white">Despesas Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">
                  As despesas cadastradas aparecerão aqui
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Illustration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-8 text-center"
        >
          <img  
            className="mx-auto rounded-xl max-w-md w-full glass-effect p-4" 
            alt="Formulário de cadastro de despesas"
           src="https://images.unsplash.com/photo-1625708974337-fb8fe9af5711" />
        </motion.div>
      </div>
    </div>
  );
};

export default ExpenseForm;
