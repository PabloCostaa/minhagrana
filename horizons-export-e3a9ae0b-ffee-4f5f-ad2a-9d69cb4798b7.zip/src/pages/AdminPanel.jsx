import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Users, Edit, Trash2, Eye, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';

const AdminPanel = () => {
  const [families, setFamilies] = useState([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newFamily, setNewFamily] = useState({
    name: '',
    email: '',
    members: '',
    budget: ''
  });
  const navigate = useNavigate();

  useEffect(() => {
    const savedFamilies = localStorage.getItem('families');
    if (savedFamilies) {
      setFamilies(JSON.parse(savedFamilies));
    } else {
      const sampleFamilies = [
        { id: 1, name: 'Família Silva', email: 'silva@email.com', members: 4, budget: 5000, expenses: 3200 },
        { id: 2, name: 'Família Santos', email: 'santos@email.com', members: 3, budget: 4000, expenses: 2800 },
        { id: 3, name: 'Família Oliveira', email: 'oliveira@email.com', members: 5, budget: 6000, expenses: 4100 }
      ];
      setFamilies(sampleFamilies);
      localStorage.setItem('families', JSON.stringify(sampleFamilies));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('auth-token');
    toast({
      title: 'Sessão encerrada',
      description: 'Você foi desconectado com sucesso.'
    });
    navigate('/login');
  };

  const handleAddFamily = (e) => {
    e.preventDefault();
    if (!newFamily.name || !newFamily.email) {
      toast({
        title: 'Erro',
        description: 'Nome e email são obrigatórios',
        variant: 'destructive'
      });
      return;
    }

    const family = {
      id: Date.now(),
      name: newFamily.name,
      email: newFamily.email,
      members: parseInt(newFamily.members) || 1,
      budget: parseFloat(newFamily.budget) || 0,
      expenses: 0
    };

    const updatedFamilies = [...families, family];
    setFamilies(updatedFamilies);
    localStorage.setItem('families', JSON.stringify(updatedFamilies));
    
    setNewFamily({ name: '', email: '', members: '', budget: '' });
    setShowAddForm(false);
    
    toast({
      title: 'Sucesso!',
      description: 'Família cadastrada com sucesso!'
    });
  };

  const handleDeleteFamily = (id) => {
    const updatedFamilies = families.filter(family => family.id !== id);
    setFamilies(updatedFamilies);
    localStorage.setItem('families', JSON.stringify(updatedFamilies));
    
    toast({
      title: 'Família removida',
      description: 'A família foi removida do sistema'
    });
  };

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <div className="flex items-center gap-4">
            <Link to="/">
              <Button variant="outline" size="icon" className="glass-effect">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-4xl font-bold gradient-text">Área Administrativa</h1>
              <p className="text-gray-300">Bem-vindo, Pablo! Gerencie as famílias.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              onClick={() => setShowAddForm(!showAddForm)}
              className="btn-gradient"
            >
              <Plus className="h-4 w-4 mr-2" />
              Nova Família
            </Button>
            <Button 
              onClick={handleLogout}
              variant="destructive"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </motion.div>

        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-8"
          >
            <Card className="admin-card">
              <CardHeader>
                <CardTitle className="text-white">Cadastrar Nova Família</CardTitle>
                <CardDescription className="text-gray-300">
                  Preencha os dados da família para cadastro no sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddFamily} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white">Nome da Família</Label>
                    <Input
                      id="name"
                      value={newFamily.name}
                      onChange={(e) => setNewFamily({...newFamily, name: e.target.value})}
                      placeholder="Ex: Família Silva"
                      className="glass-effect input-glow text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="email" className="text-white">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newFamily.email}
                      onChange={(e) => setNewFamily({...newFamily, email: e.target.value})}
                      placeholder="familia@email.com"
                      className="glass-effect input-glow text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="members" className="text-white">Número de Membros</Label>
                    <Input
                      id="members"
                      type="number"
                      value={newFamily.members}
                      onChange={(e) => setNewFamily({...newFamily, members: e.target.value})}
                      placeholder="4"
                      className="glass-effect input-glow text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="budget" className="text-white">Orçamento Mensal (R$)</Label>
                    <Input
                      id="budget"
                      type="number"
                      step="0.01"
                      value={newFamily.budget}
                      onChange={(e) => setNewFamily({...newFamily, budget: e.target.value})}
                      placeholder="5000.00"
                      className="glass-effect input-glow text-white"
                    />
                  </div>
                  <div className="md:col-span-2 flex gap-2">
                    <Button type="submit" className="btn-gradient">
                      Cadastrar Família
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowAddForm(false)}
                      className="glass-effect"
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {families.map((family, index) => (
            <motion.div
              key={family.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <Card className="expense-card">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between text-white">
                    <span className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-blue-400" />
                      {family.name}
                    </span>
                    <div className="flex gap-1">
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={() => {
                          toast({
                            title: '🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀'
                          });
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="icon" 
                        variant="ghost"
                        onClick={() => handleDeleteFamily(family.id)}
                      >
                        <Trash2 className="h-4 w-4 text-red-400" />
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Email:</span>
                      <span className="text-white">{family.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Membros:</span>
                      <span className="text-white">{family.members}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Orçamento:</span>
                      <span className="text-green-400">R$ {family.budget.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Gastos:</span>
                      <span className="text-red-400">R$ {family.expenses.toLocaleString()}</span>
                    </div>
                    <div className="pt-2">
                      <Link to={`/family/${family.id}`}>
                        <Button className="w-full btn-gradient">
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {families.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Nenhuma família cadastrada</h3>
            <p className="text-gray-400 mb-4">Comece cadastrando a primeira família no sistema</p>
            <Button onClick={() => setShowAddForm(true)} className="btn-gradient">
              <Plus className="h-4 w-4 mr-2" />
              Cadastrar Primeira Família
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;