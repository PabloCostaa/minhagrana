import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { ArrowLeft, LogIn } from 'lucide-react';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleLogin = (e) => {
    e.preventDefault();
    
    if (email.toLowerCase() === 'pablotinf@gmail.com' && password === 'Pablo1234') {
      localStorage.setItem('auth-token', 'pablo-master-user-token');
      toast({
        title: 'Login bem-sucedido!',
        description: 'Bem-vindo, Pablo!',
      });
      navigate('/admin');
    } else {
      toast({
        title: 'Erro de Autenticação',
        description: 'Email ou senha inválidos. Tente novamente.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: 'spring' }}
        className="w-full max-w-md"
      >
        <Card className="admin-card">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <LogIn className="h-12 w-12 gradient-text" />
            </div>
            <CardTitle className="text-3xl font-bold text-white">Acesso Administrativo</CardTitle>
            <CardDescription className="text-gray-300">
              Faça login para gerenciar a plataforma.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="pablo@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="glass-effect input-glow text-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-white">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="glass-effect input-glow text-white"
                />
              </div>
              <Button type="submit" className="w-full btn-gradient text-lg py-6">
                Entrar
              </Button>
            </form>
            <div className="mt-6 text-center">
              <Link to="/">
                <Button variant="link" className="text-gray-300 hover:text-white">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar para o Início
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default Login;