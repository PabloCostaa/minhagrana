import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Users, PlusCircle, BarChart3, CreditCard, TrendingUp, DollarSign, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';

const Dashboard = () => {
  const { toast } = useToast();
  const stats = [
    { title: 'Famílias Cadastradas', value: '12', icon: Users, color: 'text-blue-400' },
    { title: 'Despesas do Mês', value: 'R$ 8.450', icon: CreditCard, color: 'text-green-400' },
    { title: 'Economia Total', value: 'R$ 2.340', icon: TrendingUp, color: 'text-purple-400' },
    { title: 'Média por Família', value: 'R$ 704', icon: DollarSign, color: 'text-pink-400' }
  ];

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl font-bold gradient-text mb-4 floating-animation">
            FinanceFamily
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Sistema completo de controle financeiro familiar com gestão inteligente
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3 + index * 0.1 }}
              className="glass-effect rounded-xl p-6 card-hover pulse-glow"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-sm">{stat.title}</p>
                  <p className="text-2xl font-bold text-white">{stat.value}</p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12"
        >
          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <LogIn className="h-6 w-6 text-blue-400" />
                Área Administrativa
              </CardTitle>
              <CardDescription className="text-gray-300">
                Acesso restrito para gerenciamento de famílias e relatórios.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/login">
                <Button className="w-full btn-gradient">
                  Acessar Admin
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <PlusCircle className="h-6 w-6 text-green-400" />
                Cadastrar Despesas
              </CardTitle>
              <CardDescription className="text-gray-300">
                Interface simples para registro rápido de gastos familiares
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link to="/expenses">
                <Button className="w-full btn-gradient">
                  Adicionar Despesa
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="admin-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-white">
                <BarChart3 className="h-6 w-6 text-purple-400" />
                Relatórios
              </CardTitle>
              <CardDescription className="text-gray-300">
                Análises detalhadas e insights financeiros por família
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full btn-gradient"
                onClick={() => {
                  toast({
                    title: '🚧 Este recurso ainda não foi implementado—mas não se preocupe! Você pode solicitá-lo no seu próximo prompt! 🚀'
                  });
                }}
              >
                Ver Relatórios
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center"
        >
          <img  class="mx-auto rounded-2xl shadow-2xl max-w-4xl w-full glass-effect p-4" alt="Dashboard financeiro familiar moderno" src="https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0" />
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;