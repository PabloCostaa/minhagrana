import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Dashboard from '@/pages/Dashboard';
import AdminPanel from '@/pages/AdminPanel';
import ExpenseForm from '@/pages/ExpenseForm';
import FamilyDashboard from '@/pages/FamilyDashboard';
import Login from '@/pages/Login';
import ProtectedRoute from '@/components/ProtectedRoute';

function App() {
  return (
    <>
      <Helmet>
        <title>FinanceFamily - Controle Financeiro Familiar</title>
        <meta name="description" content="Sistema completo de controle financeiro familiar com área administrativa e cadastro de despesas" />
      </Helmet>
      <Router>
        <div className="min-h-screen">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/login" element={<Login />} />
            <Route path="/admin" element={
              <ProtectedRoute>
                <AdminPanel />
              </ProtectedRoute>
            } />
            <Route path="/expenses" element={<ExpenseForm />} />
            <Route path="/family/:familyId" element={<FamilyDashboard />} />
          </Routes>
          <Toaster />
        </div>
      </Router>
    </>
  );
}

export default App;