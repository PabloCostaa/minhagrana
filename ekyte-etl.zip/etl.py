import requests
import pandas as pd
from sqlalchemy import create_engine
import os

# Dados do ambiente
API_URL = os.getenv("EKYTE_API_URL", "https://api.ekyte.com/bi/v1/projetos")
API_TOKEN = os.getenv("EKYTE_API_TOKEN")
PG_CONN = os.getenv("POSTGRES_CONN", "postgresql://postgres:TxFEUjXbqEfbaawTVmdE@metabase-postgres:5432/metabase")

# Requisição
headers = {
    "Authorization": f"Bearer {API_TOKEN}"
}
response = requests.get(API_URL, headers=headers)

if response.status_code != 200:
    print("Erro na requisição:", response.text)
    exit(1)

data = response.json()
df = pd.DataFrame(data)

# Conecta e salva no banco
engine = create_engine(PG_CONN)
df.to_sql("ekyte_projetos", engine, if_exists='replace', index=False)

print(f"[OK] Dados salvos com sucesso: {len(df)} registros")
