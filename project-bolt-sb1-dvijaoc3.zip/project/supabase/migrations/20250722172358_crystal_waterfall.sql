/*
  # Schema inicial do sistema de controle de despesas

  1. Novas Tabelas
    - `users` - Usuários do sistema
    - `categories` - Categorias de despesas
    - `projects` - Projetos
    - `expenses` - Despesas
    - `resource_permissions` - Permissões de recursos
    - `user_resource_settings` - Configurações específicas por usuário

  2. Segurança
    - Habilitar RLS em todas as tabelas
    - Políticas de acesso baseadas em roles
    - Autenticação via Supabase Auth

  3. Dados Iniciais
    - Usuários padrão (root e pedro)
    - Categorias básicas
    - Projetos exemplo
    - Permissões padrão do sistema
*/

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de usuários (complementa o auth.users do Supabase)
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text UNIQUE NOT NULL,
  role text NOT NULL CHECK (role IN ('super_admin', 'admin', 'user')) DEFAULT 'user',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de categorias
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de projetos
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  status text NOT NULL CHECK (status IN ('active', 'inactive', 'completed')) DEFAULT 'active',
  created_by uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de despesas
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  value decimal(10,2) NOT NULL CHECK (value >= 0),
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  project_id uuid REFERENCES projects(id) ON DELETE SET NULL,
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de permissões de recursos
CREATE TABLE IF NOT EXISTS resource_permissions (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text NOT NULL,
  module text NOT NULL CHECK (module IN ('expenses', 'users', 'categories', 'projects')),
  action text NOT NULL CHECK (action IN ('view', 'create', 'edit', 'delete')),
  roles text[] NOT NULL DEFAULT '{}',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de configurações específicas por usuário
CREATE TABLE IF NOT EXISTS user_resource_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  permission_id text REFERENCES resource_permissions(id) ON DELETE CASCADE,
  is_granted boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, permission_id)
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE resource_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_resource_settings ENABLE ROW LEVEL SECURITY;

-- Políticas para users
CREATE POLICY "Users can read all users" ON users FOR SELECT TO authenticated USING (true);
CREATE POLICY "Super admins can manage users" ON users FOR ALL TO authenticated USING (
  EXISTS (
    SELECT 1 FROM users u 
    WHERE u.auth_id = auth.uid() AND u.role = 'super_admin'
  )
);

-- Políticas para categories
CREATE POLICY "Users can read categories" ON categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage categories" ON categories FOR ALL TO authenticated USING (
  EXISTS (
    SELECT 1 FROM users u 
    WHERE u.auth_id = auth.uid() AND u.role IN ('super_admin', 'admin')
  )
);

-- Políticas para projects
CREATE POLICY "Users can read projects" ON projects FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage projects" ON projects FOR ALL TO authenticated USING (
  EXISTS (
    SELECT 1 FROM users u 
    WHERE u.auth_id = auth.uid() AND u.role IN ('super_admin', 'admin')
  )
);

-- Políticas para expenses
CREATE POLICY "Users can read own expenses" ON expenses FOR SELECT TO authenticated USING (
  user_id IN (SELECT id FROM users WHERE auth_id = auth.uid())
);
CREATE POLICY "Users can manage own expenses" ON expenses FOR ALL TO authenticated USING (
  user_id IN (SELECT id FROM users WHERE auth_id = auth.uid())
);

-- Políticas para resource_permissions
CREATE POLICY "Users can read permissions" ON resource_permissions FOR SELECT TO authenticated USING (true);
CREATE POLICY "Super admins can manage permissions" ON resource_permissions FOR ALL TO authenticated USING (
  EXISTS (
    SELECT 1 FROM users u 
    WHERE u.auth_id = auth.uid() AND u.role = 'super_admin'
  )
);

-- Políticas para user_resource_settings
CREATE POLICY "Users can read own settings" ON user_resource_settings FOR SELECT TO authenticated USING (
  user_id IN (SELECT id FROM users WHERE auth_id = auth.uid())
);
CREATE POLICY "Super admins can manage all settings" ON user_resource_settings FOR ALL TO authenticated USING (
  EXISTS (
    SELECT 1 FROM users u 
    WHERE u.auth_id = auth.uid() AND u.role = 'super_admin'
  )
);

-- Inserir permissões padrão
INSERT INTO resource_permissions (id, name, description, module, action, roles) VALUES
-- Expenses module
('expenses_view', 'Visualizar Despesas', 'Permite visualizar a lista de despesas', 'expenses', 'view', ARRAY['super_admin', 'admin', 'user']),
('expenses_create', 'Criar Despesas', 'Permite cadastrar novas despesas', 'expenses', 'create', ARRAY['super_admin', 'admin', 'user']),
('expenses_edit', 'Editar Despesas', 'Permite editar despesas existentes', 'expenses', 'edit', ARRAY['super_admin', 'admin', 'user']),
('expenses_delete', 'Excluir Despesas', 'Permite excluir despesas', 'expenses', 'delete', ARRAY['super_admin', 'admin']),

-- Users module
('users_view', 'Visualizar Usuários', 'Permite visualizar a lista de usuários', 'users', 'view', ARRAY['super_admin']),
('users_create', 'Criar Usuários', 'Permite cadastrar novos usuários', 'users', 'create', ARRAY['super_admin']),
('users_edit', 'Editar Usuários', 'Permite editar usuários existentes', 'users', 'edit', ARRAY['super_admin']),
('users_delete', 'Excluir Usuários', 'Permite excluir usuários', 'users', 'delete', ARRAY['super_admin']),

-- Categories module
('categories_view', 'Visualizar Categorias', 'Permite visualizar a lista de categorias', 'categories', 'view', ARRAY['super_admin', 'admin']),
('categories_create', 'Criar Categorias', 'Permite cadastrar novas categorias', 'categories', 'create', ARRAY['super_admin', 'admin']),
('categories_edit', 'Editar Categorias', 'Permite editar categorias existentes', 'categories', 'edit', ARRAY['super_admin', 'admin']),
('categories_delete', 'Excluir Categorias', 'Permite excluir categorias', 'categories', 'delete', ARRAY['super_admin']),

-- Projects module
('projects_view', 'Visualizar Projetos', 'Permite visualizar a lista de projetos', 'projects', 'view', ARRAY['super_admin', 'admin']),
('projects_create', 'Criar Projetos', 'Permite cadastrar novos projetos', 'projects', 'create', ARRAY['super_admin', 'admin']),
('projects_edit', 'Editar Projetos', 'Permite editar projetos existentes', 'projects', 'edit', ARRAY['super_admin', 'admin']),
('projects_delete', 'Excluir Projetos', 'Permite excluir projetos', 'projects', 'delete', ARRAY['super_admin']);

-- Inserir categorias padrão
INSERT INTO categories (name, description) VALUES
('Alimentação', 'Gastos com comida e bebida'),
('Transporte', 'Gastos com locomoção'),
('Moradia', 'Aluguel, condomínio, IPTU'),
('Saúde', 'Médicos, medicamentos, planos'),
('Educação', 'Cursos, livros, material escolar'),
('Entretenimento', 'Cinema, shows, jogos'),
('Compras', 'Roupas, eletrônicos, diversos'),
('Serviços', 'Internet, telefone, streaming'),
('Outros', 'Despesas diversas');

-- Inserir projetos padrão
INSERT INTO projects (name, description, status) VALUES
('Website Empresa', 'Desenvolvimento do site institucional', 'active'),
('App Mobile', 'Aplicativo para iOS e Android', 'active'),
('Sistema ERP', 'Sistema de gestão empresarial', 'completed'),
('E-commerce', 'Loja virtual completa', 'inactive');

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para atualizar updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_categories_updated_at BEFORE UPDATE ON categories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_expenses_updated_at BEFORE UPDATE ON expenses FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_resource_permissions_updated_at BEFORE UPDATE ON resource_permissions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_resource_settings_updated_at BEFORE UPDATE ON user_resource_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();