@@ .. @@
 CREATE POLICY "Super admins can manage resource permissions"
   ON resource_permissions
   FOR ALL
   TO authenticated
-  USING (is_super_admin(uid()));
+  USING (is_super_admin(auth.uid()));
 
 CREATE POLICY "All authenticated users can read resource permissions"
   ON resource_permissions
@@ .. @@
 CREATE POLICY "Super admins can manage user resource settings"
   ON user_resource_settings
   FOR ALL
   TO authenticated
-  USING (is_super_admin(uid()));
+  USING (is_super_admin(auth.uid()));
 
 CREATE POLICY "Users can read their own resource settings"
   ON user_resource_settings
   FOR SELECT
   TO authenticated
-  USING (user_id = uid());
+  USING (user_id = auth.uid());