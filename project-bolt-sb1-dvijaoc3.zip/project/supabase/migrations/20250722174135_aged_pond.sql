@@ .. @@
 -- Enable RLS
 ALTER TABLE users ENABLE ROW LEVEL SECURITY;
 
 -- Users policies
 CREATE POLICY "Users can read own data"
   ON users
   FOR SELECT
   TO authenticated
-  USING (uid() = id);
+  USING (auth.uid() = id);
 
 CREATE POLICY "Users can update own data"
   ON users
   FOR UPDATE
   TO authenticated
-  USING (uid() = id)
-  WITH CHECK (uid() = id);
+  USING (auth.uid() = id)
+  WITH CHECK (auth.uid() = id);
 
 CREATE POLICY "Super admins can manage all users"
   ON users
   FOR ALL
   TO authenticated
-  USING (is_super_admin(uid()));
+  USING (is_super_admin(auth.uid()));
 
 -- Families policies
 CREATE POLICY "Family members can read their family"
   ON families
   FOR SELECT
   TO authenticated
-  USING (is_family_member(uid(), id));
+  USING (is_family_member(auth.uid(), id));
 
 -- Family members policies
 CREATE POLICY "Family members can read their family members"
   ON family_members
   FOR SELECT
   TO authenticated
-  USING (is_family_member(uid(), family_id));
+  USING (is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family admins can manage their family members"
   ON family_members
   FOR ALL
   TO authenticated
-  USING (is_family_admin(uid(), family_id));
+  USING (is_family_admin(auth.uid(), family_id));
 
 -- Expense categories policies
 CREATE POLICY "Family members can read their expense categories"
   ON expense_categories
   FOR SELECT
   TO authenticated
-  USING (is_family_member(uid(), family_id));
+  USING (is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family admins can manage their expense categories"
   ON expense_categories
   FOR ALL
   TO authenticated
-  USING (is_family_admin(uid(), family_id));
+  USING (is_family_admin(auth.uid(), family_id));
 
 -- Expenses policies
 CREATE POLICY "Family members can read their family expenses"
   ON expenses
   FOR SELECT
   TO authenticated
-  USING (is_family_member(uid(), family_id));
+  USING (is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family members can manage their own expenses"
   ON expenses
   FOR ALL
   TO authenticated
-  USING ((created_by = uid()) AND is_family_member(uid(), family_id));
+  USING ((created_by = auth.uid()) AND is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family admins can manage their family expenses"
   ON expenses
   FOR ALL
   TO authenticated
-  USING (is_family_admin(uid(), family_id));
+  USING (is_family_admin(auth.uid(), family_id));
 
 -- Recurring expenses policies
 CREATE POLICY "Family members can read their family recurring expenses"
   ON recurring_expenses
   FOR SELECT
   TO authenticated
-  USING (is_family_member(uid(), family_id));
+  USING (is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family members can manage their own recurring expenses"
   ON recurring_expenses
   FOR ALL
   TO authenticated
-  USING ((created_by = uid()) AND is_family_member(uid(), family_id));
+  USING ((created_by = auth.uid()) AND is_family_member(auth.uid(), family_id));
 
 CREATE POLICY "Family admins can manage their family recurring expenses"
   ON recurring_expenses
   FOR ALL
   TO authenticated
-  USING (is_family_admin(uid(), family_id));
+  USING (is_family_admin(auth.uid(), family_id));