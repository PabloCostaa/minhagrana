import React, { useState, useEffect } from 'react';
import { Settings, Shield, Users, Eye, Plus, Edit3, Trash2, Save, RotateCcw, User } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { ResourcePermission, User as UserType, UserResourceSettings } from '../../types';
import { supabase } from '../../lib/supabase';

export function ResourcesManagement() {
  const { permissions, userSettings, updateUserSettings, user } = useAuth();
  const [users, setUsers] = useState<UserType[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [localUserSettings, setLocalUserSettings] = useState<UserResourceSettings[]>(userSettings);
  const [hasChanges, setHasChanges] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    setLocalUserSettings(userSettings);
  }, [userSettings]);

  const loadUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading users:', error);
        return;
      }

      const formattedUsers: UserType[] = data.map(u => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        createdAt: new Date(u.created_at)
      }));

      setUsers(formattedUsers);
    } catch (error) {
      console.error('Error in loadUsers:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectedUser = users.find(u => u.id === selectedUserId);
  const currentUserSettings = localUserSettings.find(s => s.userId === selectedUserId);

  const handlePermissionToggle = (permissionId: string) => {
    if (!selectedUserId) return;

    const updatedSettings = [...localUserSettings];
    const userSettingIndex = updatedSettings.findIndex(s => s.userId === selectedUserId);

    if (userSettingIndex >= 0) {
      const currentPermissions = updatedSettings[userSettingIndex].permissions;
      const hasPermission = currentPermissions.includes(permissionId);
      
      updatedSettings[userSettingIndex] = {
        ...updatedSettings[userSettingIndex],
        permissions: hasPermission
          ? currentPermissions.filter(p => p !== permissionId)
          : [...currentPermissions, permissionId]
      };
    } else {
      // Create new user settings
      updatedSettings.push({
        userId: selectedUserId,
        permissions: [permissionId]
      });
    }

    setLocalUserSettings(updatedSettings);
    setHasChanges(true);
  };

  const saveChanges = async () => {
    await updateUserSettings(localUserSettings);
    setHasChanges(false);
  };

  const resetChanges = () => {
    setLocalUserSettings(userSettings);
    setHasChanges(false);
  };

  const resetUserPermissions = () => {
    if (!selectedUserId) return;
    
    const updatedSettings = localUserSettings.filter(s => s.userId !== selectedUserId);
    setLocalUserSettings(updatedSettings);
    setHasChanges(true);
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    if (!confirm(`Tem certeza que deseja excluir o usuário "${userName}"?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('users')
        .delete()
        .eq('id', userId);

      if (error) {
        console.error('Error deleting user:', error);
        return;
      }

      // Remove from local state
      setUsers(prev => prev.filter(u => u.id !== userId));
      
      // Clear selection if deleted user was selected
      if (selectedUserId === userId) {
        setSelectedUserId('');
      }

      // Remove user settings
      const updatedSettings = localUserSettings.filter(s => s.userId !== userId);
      setLocalUserSettings(updatedSettings);
      setHasChanges(true);
    } catch (error) {
      console.error('Error in handleDeleteUser:', error);
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'super_admin': return 'Super Admin';
      case 'admin': return 'Admin';
      case 'user': return 'Usuário';
      default: return role;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'super_admin': return 'bg-purple-100 text-purple-800';
      case 'admin': return 'bg-blue-100 text-blue-800';
      case 'user': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getModuleIcon = (module: string) => {
    switch (module) {
      case 'expenses': return '💰';
      case 'users': return '👥';
      case 'categories': return '🏷️';
      case 'projects': return '📁';
      default: return '⚙️';
    }
  };

  const getActionIcon = (permission: string) => {
    switch (permission) {
      case 'view': return <Eye className="w-4 h-4" />;
      case 'create': return <Plus className="w-4 h-4" />;
      case 'edit': return <Edit3 className="w-4 h-4" />;
      case 'delete': return <Trash2 className="w-4 h-4" />;
      default: return <Settings className="w-4 h-4" />;
    }
  };

  const isPermissionEnabled = (permission: ResourcePermission): boolean => {
    if (!selectedUserId || !selectedUser) return false;
    
    // Check if user has custom settings
    if (currentUserSettings) {
      return currentUserSettings.permissions.includes(permission.id);
    }
    
    // Default permissions based on role
    if (selectedUser.role === 'super_admin') return true;
    if (selectedUser.role === 'admin' && ['expenses', 'categories', 'projects'].includes(permission.module)) return true;
    if (selectedUser.role === 'user' && permission.module === 'expenses') return true;
    
    return false;
  };

  const groupedPermissions = permissions.reduce((acc, permission) => {
    if (!acc[permission.module]) {
      acc[permission.module] = [];
    }
    acc[permission.module].push(permission);
    return acc;
  }, {} as Record<string, ResourcePermission[]>);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Settings className="w-8 h-8 text-indigo-600" />
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Controle de Recursos por Usuário</h1>
            <p className="text-gray-600">Configure permissões específicas para cada usuário</p>
          </div>
        </div>
        
        {hasChanges && (
          <div className="flex space-x-3">
            <button
              onClick={resetChanges}
              className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors flex items-center space-x-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Cancelar</span>
            </button>
            <button
              onClick={saveChanges}
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors flex items-center space-x-2"
            >
              <Save className="w-4 h-4" />
              <span>Salvar Alterações</span>
            </button>
          </div>
        )}
      </div>

      {hasChanges && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-center">
            <Shield className="w-5 h-5 text-amber-600 mr-2" />
            <span className="text-amber-800 font-medium">
              Você tem alterações não salvas. Clique em "Salvar Alterações" para aplicar.
            </span>
          </div>
        </div>
      )}

      {/* User Selection */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Users className="w-6 h-6 text-indigo-600" />
            <h2 className="text-lg font-semibold text-gray-800">Lista de Usuários</h2>
          </div>
        </div>

        <p className="text-sm text-gray-600 mb-4">Clique no ícone de lápis para configurar permissões do usuário</p>
        
        <div className="divide-y divide-gray-200">
          {users.map((user) => {
            const userCustomSettings = localUserSettings.find(s => s.userId === user.id);
            const hasCustomPermissions = userCustomSettings && userCustomSettings.permissions.length > 0;
            
            return (
              <div
                key={user.id}
                className="p-6 hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gray-100 p-3 rounded-full">
                      <User className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 text-lg">{user.name}</h4>
                      <p className="text-gray-600">{user.email}</p>
                      <div className="flex items-center space-x-3 mt-2">
                        <span className={`inline-block px-3 py-1 text-sm font-medium rounded-full ${getRoleColor(user.role)}`}>
                          {getRoleLabel(user.role)}
                        </span>
                        {hasCustomPermissions && (
                          <span className="inline-block px-3 py-1 text-sm font-medium rounded-full bg-blue-100 text-blue-800">
                            Configuração Personalizada
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-sm text-gray-500 mb-1">Cadastrado em</p>
                      <p className="text-sm font-medium text-gray-800">
                        {user.createdAt.toLocaleDateString('pt-BR')}
                      </p>
                      {hasCustomPermissions && (
                        <p className="text-xs text-blue-600 mt-1">
                          {userCustomSettings.permissions.length} permissão{userCustomSettings.permissions.length !== 1 ? 'ões' : ''} personalizada{userCustomSettings.permissions.length !== 1 ? 's' : ''}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => setSelectedUserId(user.id)}
                        className="p-2 text-gray-400 hover:text-blue-600 transition-colors rounded-lg hover:bg-blue-50"
                        title="Configurar permissões"
                      >
                        <Edit3 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDeleteUser(user.id, user.name)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors rounded-lg hover:bg-red-50"
                        title="Excluir usuário"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Permissions Configuration */}
      {selectedUser && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Shield className="w-6 h-6 text-indigo-600" />
                <div>
                  <h2 className="text-lg font-semibold text-gray-800">
                    Permissões para {selectedUser.name}
                  </h2>
                  <p className="text-sm text-gray-600">
                    Perfil: {getRoleLabel(selectedUser.role)} • {selectedUser.email}
                  </p>
                </div>
              </div>
              
              <div className="text-sm text-gray-600">
                {currentUserSettings ? (
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                    Configuração personalizada
                  </span>
                ) : (
                  <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                    Usando permissões padrão do perfil
                  </span>
                )}
              </div>
            </div>
          </div>

          {Object.entries(groupedPermissions).map(([module, modulePermissions]) => (
            <div key={module} className="bg-white rounded-xl shadow-lg border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{getModuleIcon(module)}</span>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 capitalize">
                      Módulo: {module === 'expenses' ? 'Despesas' : 
                               module === 'users' ? 'Usuários' : 
                               module === 'categories' ? 'Categorias' : 
                               module === 'projects' ? 'Projetos' : module}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {modulePermissions.length} permissão{modulePermissions.length !== 1 ? 'ões' : ''} disponível{modulePermissions.length !== 1 ? 'eis' : ''}
                    </p>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {modulePermissions.map((permission) => (
                    <div key={permission.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full">
                            {getActionIcon(permission.permission)}
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-800 capitalize">{permission.permission}</h4>
                            <p className="text-sm text-gray-600">Permissão de {permission.permission} no módulo {permission.module}</p>
                          </div>
                        </div>
                        
                        <button
                          onClick={() => handlePermissionToggle(permission.id)}
                          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                            isPermissionEnabled(permission) ? 'bg-indigo-600' : 'bg-gray-200'
                          }`}
                        >
                          <span
                            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                              isPermissionEnabled(permission) ? 'translate-x-6' : 'translate-x-1'
                            }`}
                          />
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">
                          Padrão do perfil: {(() => {
                            if (selectedUser.role === 'super_admin') return 'Ativo';
                            if (selectedUser.role === 'admin' && ['expenses', 'categories', 'projects'].includes(permission.module)) return 'Ativo';
                            if (selectedUser.role === 'user' && permission.module === 'expenses') return 'Ativo';
                            return 'Inativo';
                          })()}
                        </span>
                        <span className={`font-medium ${
                          isPermissionEnabled(permission) ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {isPermissionEnabled(permission) ? 'Permitido' : 'Negado'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}