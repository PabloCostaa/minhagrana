import React, { useState, useEffect } from 'react';
import { PlusCircle, Trash2, Edit3, DollarSign, Tag, FileText, TrendingDown, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

interface Expense {
  id: string;
  name: string;
  value: number;
  categoryId: string;
  projectId: string;
  createdAt: Date;
}

interface Category {
  id: string;
  name: string;
}

interface Project {
  id: string;
  name: string;
}

export function ExpenseTracker() {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    value: '',
    categoryId: '',
    projectId: ''
  });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    try {
      // Load categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('categories')
        .select('id, name')
        .order('name');

      if (categoriesError) {
        setError('Erro ao carregar categorias: ' + categoriesError.message);
        return;
      }

      setCategories(categoriesData || []);

      // Load projects
      const { data: projectsData, error: projectsError } = await supabase
        .from('projects')
        .select('id, name')
        .eq('status', 'active')
        .order('name');

      if (projectsError) {
        setError('Erro ao carregar projetos: ' + projectsError.message);
        return;
      }

      setProjects(projectsData || []);

      // Load expenses
      const { data: expensesData, error: expensesError } = await supabase
        .from('expenses')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (expensesError) {
        setError('Erro ao carregar despesas: ' + expensesError.message);
        return;
      }

      const formattedExpenses: Expense[] = (expensesData || []).map(e => ({
        id: e.id,
        name: e.name,
        value: parseFloat(e.value),
        categoryId: e.category_id,
        projectId: e.project_id,
        createdAt: new Date(e.created_at)
      }));

      setExpenses(formattedExpenses);
    } catch (err: any) {
      setError('Erro ao carregar dados: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!formData.name.trim() || !formData.value || !formData.categoryId || !formData.projectId) {
      setError('Todos os campos são obrigatórios');
      return;
    }

    if (!user) {
      setError('Usuário não autenticado');
      return;
    }

    try {
      const expenseData = {
        name: formData.name.trim(),
        value: parseFloat(formData.value),
        category_id: formData.categoryId,
        project_id: formData.projectId,
        user_id: user.id
      };

      if (editingId) {
        // Update existing expense
        const { error } = await supabase
          .from('expenses')
          .update(expenseData)
          .eq('id', editingId);

        if (error) {
          setError('Erro ao atualizar despesa: ' + error.message);
          return;
        }

        setSuccess('Despesa atualizada com sucesso!');
      } else {
        // Create new expense
        const { error } = await supabase
          .from('expenses')
          .insert(expenseData);

        if (error) {
          setError('Erro ao criar despesa: ' + error.message);
          return;
        }

        setSuccess('Despesa criada com sucesso!');
      }

      setFormData({ name: '', value: '', categoryId: '', projectId: '' });
      setEditingId(null);
      loadData();
    } catch (err: any) {
      setError('Erro inesperado: ' + err.message);
    }
  };

  const handleEdit = (expense: Expense) => {
    setFormData({
      name: expense.name,
      value: expense.value.toString(),
      categoryId: expense.categoryId,
      projectId: expense.projectId
    });
    setEditingId(expense.id);
    setError('');
    setSuccess('');
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Tem certeza que deseja excluir a despesa "${name}"?`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('expenses')
        .delete()
        .eq('id', id);

      if (error) {
        setError('Erro ao excluir despesa: ' + error.message);
        return;
      }

      setSuccess('Despesa excluída com sucesso!');
      loadData();
    } catch (err: any) {
      setError('Erro ao excluir despesa: ' + err.message);
    }
  };

  const cancelEdit = () => {
    setFormData({ name: '', value: '', categoryId: '', projectId: '' });
    setEditingId(null);
    setError('');
    setSuccess('');
  };

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.value, 0);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const getCategoryName = (categoryId: string) => {
    return categories.find(c => c.id === categoryId)?.name || 'Categoria não encontrada';
  };

  const getProjectName = (projectId: string) => {
    return projects.find(p => p.id === projectId)?.name || 'Projeto não encontrado';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-3">
        <TrendingDown className="w-8 h-8 text-blue-600" />
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Controle de Despesas</h1>
          <p className="text-gray-600">Gerencie suas despesas de forma simples e eficiente</p>
        </div>
      </div>

      {/* Messages */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center">
          <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
          <span className="text-red-700">{error}</span>
        </div>
      )}

      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
          <TrendingDown className="w-5 h-5 text-green-500 mr-2" />
          <span className="text-green-700">{success}</span>
        </div>
      )}

      {/* Stats Card */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-600 text-sm font-medium">Total de Despesas</p>
            <p className="text-2xl font-bold text-gray-800">{formatCurrency(totalExpenses)}</p>
          </div>
          <div className="bg-blue-50 p-3 rounded-full">
            <DollarSign className="w-6 h-6 text-blue-600" />
          </div>
        </div>
        <div className="mt-4 flex items-center text-sm">
          <span className="text-gray-600">{expenses.length} despesa{expenses.length !== 1 ? 's' : ''} cadastrada{expenses.length !== 1 ? 's' : ''}</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-200">
          <div className="flex items-center mb-6">
            <PlusCircle className="w-6 h-6 text-blue-600 mr-3" />
            <h2 className="text-xl font-semibold text-gray-800">
              {editingId ? 'Editar Despesa' : 'Nova Despesa'}
            </h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="w-4 h-4 inline mr-1" />
                Nome da Despesa
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                placeholder="Ex: Supermercado, Gasolina, Aluguel..."
                required
              />
            </div>

            <div>
              <label htmlFor="value" className="block text-sm font-medium text-gray-700 mb-2">
                <DollarSign className="w-4 h-4 inline mr-1" />
                Valor (R$)
              </label>
              <input
                type="number"
                id="value"
                step="0.01"
                min="0"
                value={formData.value}
                onChange={(e) => setFormData(prev => ({ ...prev, value: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                placeholder="0,00"
                required
              />
            </div>

            <div>
              <label htmlFor="categoryId" className="block text-sm font-medium text-gray-700 mb-2">
                <Tag className="w-4 h-4 inline mr-1" />
                Categoria
              </label>
              <select
                id="categoryId"
                value={formData.categoryId}
                onChange={(e) => setFormData(prev => ({ ...prev, categoryId: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                required
              >
                <option value="">Selecione uma categoria</option>
                {categories.map(category => (
                  <option key={category.id} value={category.id}>{category.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="projectId" className="block text-sm font-medium text-gray-700 mb-2">
                <FileText className="w-4 h-4 inline mr-1" />
                Projeto
              </label>
              <select
                id="projectId"
                value={formData.projectId}
                onChange={(e) => setFormData(prev => ({ ...prev, projectId: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                required
              >
                <option value="">Selecione um projeto</option>
                {projects.map(project => (
                  <option key={project.id} value={project.id}>{project.name}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-3">
              <button
                type="submit"
                className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors flex items-center justify-center"
              >
                <PlusCircle className="w-5 h-5 mr-2" />
                {editingId ? 'Atualizar' : 'Cadastrar'}
              </button>
              {editingId && (
                <button
                  type="button"
                  onClick={cancelEdit}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                >
                  Cancelar
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Expenses List */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Despesas Recentes</h2>
          </div>
          
          <div className="max-h-96 overflow-y-auto">
            {expenses.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <TrendingDown className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>Nenhuma despesa cadastrada</p>
                <p className="text-sm">Cadastre sua primeira despesa ao lado</p>
              </div>
            ) : (
              <div className="space-y-2 p-4">
                {expenses.map((expense) => (
                  <div
                    key={expense.id}
                    className={`p-4 rounded-lg border transition-colors ${
                      editingId === expense.id
                        ? 'border-blue-200 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-medium text-gray-800 truncate">{expense.name}</h3>
                        <div className="flex items-center mt-1 text-sm text-gray-600">
                          <Tag className="w-3 h-3 mr-1" />
                          <span>{getCategoryName(expense.categoryId)}</span>
                          <span className="mx-2">•</span>
                          <span className="text-blue-600 font-medium">{getProjectName(expense.projectId)}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <span className="font-semibold text-gray-800">
                          {formatCurrency(expense.value)}
                        </span>
                        <div className="flex space-x-1">
                          <button
                            onClick={() => handleEdit(expense)}
                            className="p-1 text-gray-400 hover:text-blue-600 transition-colors"
                            title="Editar despesa"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(expense.id, expense.name)}
                            className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                            title="Excluir despesa"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}