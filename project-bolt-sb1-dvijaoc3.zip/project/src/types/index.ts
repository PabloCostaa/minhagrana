export interface User {
  id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'admin' | 'user';
  createdAt: Date;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  createdAt: Date;
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  status: 'active' | 'inactive' | 'completed';
  createdAt: Date;
}

export interface Expense {
  id: string;
  name: string;
  value: number;
  categoryId: string;
  projectId: string;
  userId: string;
  createdAt: Date;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface ResourcePermission {
  id: string;
  module: string;
  permission: string;
}

export interface UserResourceSettings {
  userId: string;
  permissions: string[]; // Array of permission IDs
}