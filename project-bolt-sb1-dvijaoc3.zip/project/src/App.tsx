import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginForm } from './components/LoginForm';
import { AdminLayout } from './components/AdminLayout';
import { ExpenseTracker } from './components/ExpenseTracker';
import { UsersManagement } from './components/admin/UsersManagement';
import { CategoriesManagement } from './components/admin/CategoriesManagement';
import { ProjectsManagement } from './components/admin/ProjectsManagement';
import { ResourcesManagement } from './components/admin/ResourcesManagement';

function AppContent() {
  const { isAuthenticated, user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState('expenses');

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'expenses':
        return <ExpenseTracker />;
      case 'resources':
        return user?.role === 'super_admin' ? <ResourcesManagement /> : <ExpenseTracker />;
      case 'users':
        return user?.role === 'super_admin' ? <UsersManagement /> : <ExpenseTracker />;
      case 'categories':
        return user?.role === 'super_admin' || user?.role === 'admin' ? <CategoriesManagement /> : <ExpenseTracker />;
      case 'projects':
        return user?.role === 'super_admin' || user?.role === 'admin' ? <ProjectsManagement /> : <ExpenseTracker />;
      default:
        return <ExpenseTracker />;
    }
  };

  return (
    <AdminLayout currentPage={currentPage} onPageChange={setCurrentPage}>
      {renderPage()}
    </AdminLayout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;