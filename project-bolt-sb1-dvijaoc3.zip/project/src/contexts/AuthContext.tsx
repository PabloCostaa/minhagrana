import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, AuthState, ResourcePermission, UserResourceSettings } from '../types';
import { useSupabaseAuth } from '../hooks/useSupabaseAuth';
import { supabase } from '../lib/supabase';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
  permissions: ResourcePermission[];
  userSettings: UserResourceSettings[];
  updatePermissions: (permissions: ResourcePermission[]) => void;
  updateUserSettings: (settings: UserResourceSettings[]) => void;
  hasPermission: (module: string, action: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading, signIn, signOut } = useSupabaseAuth();
  const [permissions, setPermissions] = useState<ResourcePermission[]>([]);
  const [userSettings, setUserSettings] = useState<UserResourceSettings[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!authLoading) {
      loadPermissions();
      loadUserSettings();
      setLoading(false);
    }
  }, [authLoading, user]);

  const loadPermissions = async () => {
    try {
      const { data, error } = await supabase
        .from('resource_permissions')
        .select('*')
        .order('id', { ascending: true });

      if (error) {
        console.error('Error loading permissions:', error);
        return;
      }

      const formattedPermissions: ResourcePermission[] = data.map(p => ({
        id: p.id.toString(),
        module: p.module,
        permission: p.permission
      }));

      setPermissions(formattedPermissions);
    } catch (error) {
      console.error('Error in loadPermissions:', error);
    }
  };

  const loadUserSettings = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('user_resource_settings')
        .select('*');

      if (error) {
        console.error('Error loading user settings:', error);
        return;
      }

      // Group by user_id
      const settingsMap: { [userId: string]: string[] } = {};
      data.forEach(setting => {
        if (!settingsMap[setting.user_id]) {
          settingsMap[setting.user_id] = [];
        }
        if (setting.is_granted) {
          settingsMap[setting.user_id].push(setting.permission_id);
        }
      });

      const formattedSettings: UserResourceSettings[] = Object.entries(settingsMap).map(([userId, permissions]) => ({
        userId,
        permissions
      }));

      setUserSettings(formattedSettings);
    } catch (error) {
      console.error('Error in loadUserSettings:', error);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    const result = await signIn(email, password);
    return result.success;
  };

  const logout = () => {
    signOut();
  };

  const updatePermissions = async (newPermissions: ResourcePermission[]) => {
    // This would typically update the database
    setPermissions(newPermissions);
  };

  const updateUserSettings = async (newSettings: UserResourceSettings[]) => {
    if (!user || user.role !== 'super_admin') return;

    try {
      // Clear existing settings for all users in the new settings
      const userIds = newSettings.map(s => s.userId);
      if (userIds.length > 0) {
        await supabase
          .from('user_resource_settings')
          .delete()
          .in('user_id', userIds);
      }

      // Insert new settings
      const settingsToInsert = newSettings.flatMap(userSetting =>
        userSetting.permissions.map(permissionId => ({
          user_id: userSetting.userId,
          permission_id: permissionId,
          is_granted: true
        }))
      );

      if (settingsToInsert.length > 0) {
        const { error } = await supabase
          .from('user_resource_settings')
          .insert(settingsToInsert);

        if (error) {
          console.error('Error updating user settings:', error);
          return;
        }
      }

      setUserSettings(newSettings);
    } catch (error) {
      console.error('Error in updateUserSettings:', error);
    }
  };

  const hasPermission = (module: string, action: string): boolean => {
    if (!user) return false;
    
    const permission = permissions.find(p => p.module === module && p.permission === action);
    
    if (!permission) return false;
    
    // Check user-specific settings
    const userSetting = userSettings.find(s => s.userId === user.id);
    if (userSetting) {
      return userSetting.permissions.includes(permission.id);
    }
    
    // Default permissions based on role
    if (user.role === 'super_admin') return true;
    if (user.role === 'admin' && ['expenses', 'categories', 'projects'].includes(module)) return true;
    if (user.role === 'user' && module === 'expenses') return true;
    
    return false;
  };

  return (
    <AuthContext.Provider value={{ 
      user,
      isAuthenticated: !!user,
      login, 
      logout, 
      loading: loading || authLoading,
      permissions, 
      userSettings, 
      updatePermissions, 
      updateUserSettings, 
      hasPermission 
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}