import requests
import pandas as pd
from sqlalchemy import create_engine
import os

# Configuração geral
API_BASE_URL = "https://api.ekyte.com/bi/v1"
API_TOKEN = os.getenv("EKYTE_API_TOKEN")
PG_CONN = os.getenv("POSTGRES_CONN", "postgresql://postgres:TxFEUjXbqEfbaawTVmdE@metabase-postgres:5432/metabase")

# Endpoints disponíveis da API do eKyte BI
endpoints = [
    "projetos",
    "tarefas",
    "investimentos",
    "clientes",
    "membros",
    "entregas",
    "campanhas",
    "veiculacoes",
    "cronogramas",
    "etapas",
]

headers = {
    "Authorization": f"Bearer {API_TOKEN}"
}

# Conexão com o banco
engine = create_engine(PG_CONN)

for endpoint in endpoints:
    url = f"{API_BASE_URL}/{endpoint}"
    print(f"🔄 Coletando dados de: {url}")
    try:
        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            print(f"⚠️ Erro ao buscar {endpoint}: {response.status_code} - {response.text}")
            continue

        data = response.json()
        df = pd.DataFrame(data)

        if df.empty:
            print(f"⚠️ Nenhum dado encontrado em: {endpoint}")
            continue

        df.to_sql(f"ekyte_{endpoint}", engine, if_exists='replace', index=False)
        print(f"✅ {endpoint}: {len(df)} registros salvos")
    except Exception as e:
        print(f"❌ Erro processando {endpoint}: {e}")
