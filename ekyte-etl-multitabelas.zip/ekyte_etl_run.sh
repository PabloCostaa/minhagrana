#!/bin/bash
docker service rm ekyteetl_etl || true
docker stack deploy -c /opt/docker-stacks/ekyte-etl/ekyte_etl.yaml ekyteetl
