/*
  # MinhaGrana Database Schema

  1. New Tables
    - `users` - User accounts (handled by Supabase Auth)
    - `categories` - User-defined expense categories
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text)
      - `color` (text)
      - `created_at` (timestamp)
    - `expenses` - User expenses with recurrence support
      - `id` (uuid, primary key)  
      - `user_id` (uuid, references auth.users)
      - `name` (text)
      - `amount` (numeric)
      - `date` (date)
      - `category_id` (uuid, references categories)
      - `recurrence` (text enum)
      - `notes` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Users can only access their own categories and expenses

  3. Indexes
    - Add indexes for performance on commonly queried fields
*/

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  color text DEFAULT '#10B981',
  created_at timestamptz DEFAULT now()
);

-- Expenses table  
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  amount numeric(10, 2) NOT NULL,
  date date NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  recurrence text CHECK (recurrence IN ('none', 'weekly', 'monthly')) DEFAULT 'none',
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Categories policies
CREATE POLICY "Users can read own categories"
  ON categories
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own categories"
  ON categories
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own categories"
  ON categories
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own categories"
  ON categories
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Expenses policies
CREATE POLICY "Users can read own expenses"
  ON expenses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own expenses"
  ON expenses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own expenses"
  ON expenses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own expenses"
  ON expenses
  FOR DELETE
  TO authenticated  
  USING (auth.uid() = user_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_categories_user_id ON categories(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);
CREATE INDEX IF NOT EXISTS idx_expenses_category_id ON expenses(category_id);

-- Insert default categories
INSERT INTO categories (user_id, name, color) 
SELECT 
  auth.uid(),
  unnest(ARRAY['Alimentação', 'Transporte', 'Saúde', 'Lazer', 'Casa', 'Educação']),
  unnest(ARRAY['#10B981', '#3B82F6', '#EF4444', '#F97316', '#8B5CF6', '#06B6D4'])
WHERE auth.uid() IS NOT NULL
ON CONFLICT DO NOTHING;