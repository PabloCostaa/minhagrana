/*
  # Create categories table

  1. New Tables
    - `categories`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `name` (text)
      - `color` (text, default green)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `categories` table
    - Add policies for authenticated users to manage their own categories

  3. Default Categories
    - Insert default categories for new users
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text DEFAULT '#10B981',
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_categories_user_id ON public.categories(user_id);

-- Enable RLS
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own categories"
  ON public.categories
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own categories"
  ON public.categories
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own categories"
  ON public.categories
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own categories"
  ON public.categories
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to insert default categories
CREATE OR REPLACE FUNCTION public.insert_default_categories()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.categories (user_id, name, color) VALUES
    (new.id, 'Alimentação', '#EF4444'),
    (new.id, 'Transporte', '#3B82F6'),
    (new.id, 'Moradia', '#10B981'),
    (new.id, 'Saúde', '#F59E0B'),
    (new.id, 'Educação', '#8B5CF6'),
    (new.id, 'Lazer', '#EC4899'),
    (new.id, 'Outros', '#6B7280');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for default categories
DROP TRIGGER IF EXISTS on_user_created_categories ON public.users;
CREATE TRIGGER on_user_created_categories
  AFTER INSERT ON public.users
  FOR EACH ROW EXECUTE FUNCTION public.insert_default_categories();