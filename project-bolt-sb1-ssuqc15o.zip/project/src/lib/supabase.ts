import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://ggzkqpnhnqqkazbsgzrh.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdnemtxcG5obnFxa2F6YnNnenJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMyMTU1NDksImV4cCI6MjA2ODc5MTU0OX0.aWE56fnJrYAHRUvdWvX9tPYIoe7oWLD1FVZjyh9bdLk'

console.log('Supabase config:', { url: supabaseUrl, hasKey: !!supabaseAnonKey })

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Test connection
supabase.auth.getSession().then(({ data, error }) => {
  console.log('Supabase connection test:', { hasData: !!data, error })
}).catch(err => {
  console.error('Supabase connection failed:', err)
})

export type Database = {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string
          user_id: string
          name: string
          color: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          color?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          color?: string
          created_at?: string
        }
      }
      expenses: {
        Row: {
          id: string
          user_id: string
          name: string
          amount: number
          date: string
          category_id: string | null
          recurrence: 'none' | 'weekly' | 'monthly'
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          amount: number
          date: string
          category_id?: string | null
          recurrence?: 'none' | 'weekly' | 'monthly'
          notes?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          amount?: number
          date?: string
          category_id?: string | null
          recurrence?: 'none' | 'weekly' | 'monthly'
          notes?: string | null
          created_at?: string
        }
      }
    }
  }
}