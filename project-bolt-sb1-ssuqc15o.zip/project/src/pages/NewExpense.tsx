import React from 'react'
import { ExpenseForm } from '../components/expenses/ExpenseForm'
import { useNavigate } from 'react-router-dom'

export function NewExpense() {
  const navigate = useNavigate()

  const handleSuccess = () => {
    navigate('/')
  }

  return (
    <div className="max-w-2xl mx-auto">
      <ExpenseForm onSuccess={handleSuccess} />
    </div>
  )
}