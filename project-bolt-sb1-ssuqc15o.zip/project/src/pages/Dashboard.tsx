import React, { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { supabase } from '../lib/supabase'
import { StatCard } from '../components/dashboard/StatCard'
import { ExpenseChart } from '../components/dashboard/ExpenseChart'
import { ExpenseList } from '../components/expenses/ExpenseList'
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  PieChart,
  Download
} from 'lucide-react'
import { 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek,
  format,
  parseISO,
  eachDayOfInterval
} from 'date-fns'
import { ptBR } from 'date-fns/locale'
import toast from 'react-hot-toast'

interface DashboardStats {
  monthlyTotal: number
  weeklyTotal: number
  monthlyProjection: number
  expensesByCategory: Array<{ name: string; value: number; color: string }>
  dailyExpenses: Array<{ date: string; amount: number }>
}

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    monthlyTotal: 0,
    weeklyTotal: 0,
    monthlyProjection: 0,
    expensesByCategory: [],
    dailyExpenses: []
  })
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      loadDashboardData()
    }
  }, [user])

  const loadDashboardData = async () => {
    if (!user) return

    try {
      setLoading(true)
      
      const now = new Date()
      const monthStart = startOfMonth(now)
      const monthEnd = endOfMonth(now)
      const weekStart = startOfWeek(now)
      const weekEnd = endOfWeek(now)

      // Load expenses for current month
      const { data: monthlyExpenses, error: monthlyError } = await supabase
        .from('expenses')
        .select(`
          *,
          category:categories(name, color)
        `)
        .eq('user_id', user.id)
        .gte('date', format(monthStart, 'yyyy-MM-dd'))
        .lte('date', format(monthEnd, 'yyyy-MM-dd'))

      if (monthlyError) throw monthlyError

      // Load expenses for current week
      const { data: weeklyExpenses, error: weeklyError } = await supabase
        .from('expenses')
        .select('amount')
        .eq('user_id', user.id)
        .gte('date', format(weekStart, 'yyyy-MM-dd'))
        .lte('date', format(weekEnd, 'yyyy-MM-dd'))

      if (weeklyError) throw weeklyError

      // Calculate totals
      const monthlyTotal = monthlyExpenses?.reduce((sum, expense) => sum + Number(expense.amount), 0) || 0
      const weeklyTotal = weeklyExpenses?.reduce((sum, expense) => sum + Number(expense.amount), 0) || 0

      // Calculate expenses by category
      const categoryTotals = new Map<string, { name: string; value: number; color: string }>()
      
      monthlyExpenses?.forEach(expense => {
        const categoryName = expense.category?.name || 'Sem categoria'
        const categoryColor = expense.category?.color || '#10B981'
        
        if (categoryTotals.has(categoryName)) {
          categoryTotals.get(categoryName)!.value += Number(expense.amount)
        } else {
          categoryTotals.set(categoryName, {
            name: categoryName,
            value: Number(expense.amount),
            color: categoryColor
          })
        }
      })

      const expensesByCategory = Array.from(categoryTotals.values())

      // Calculate daily expenses for chart
      const dailyTotals = new Map<string, number>()
      const monthDays = eachDayOfInterval({ start: monthStart, end: monthEnd })
      
      // Initialize all days with 0
      monthDays.forEach(day => {
        dailyTotals.set(format(day, 'yyyy-MM-dd'), 0)
      })

      // Add actual expenses
      monthlyExpenses?.forEach(expense => {
        const dateKey = expense.date
        dailyTotals.set(dateKey, (dailyTotals.get(dateKey) || 0) + Number(expense.amount))
      })

      const dailyExpenses = Array.from(dailyTotals.entries()).map(([date, amount]) => ({
        date: format(parseISO(date), 'dd/MM'),
        amount
      }))

      // Calculate monthly projection (simple average * days remaining)
      const daysInMonth = monthDays.length
      const daysPassed = Math.max(1, new Date().getDate())
      const avgDaily = monthlyTotal / daysPassed
      const monthlyProjection = avgDaily * daysInMonth

      setStats({
        monthlyTotal,
        weeklyTotal,
        monthlyProjection,
        expensesByCategory,
        dailyExpenses
      })
    } catch (error) {
      console.error('Error loading dashboard data:', error)
      toast.error('Erro ao carregar dados do dashboard')
    } finally {
      setLoading(false)
    }
  }

  const exportToCsv = async () => {
    if (!user) return

    try {
      const { data: expenses, error } = await supabase
        .from('expenses')
        .select(`
          name,
          amount,
          date,
          recurrence,
          notes,
          category:categories(name)
        `)
        .eq('user_id', user.id)
        .order('date', { ascending: false })

      if (error) throw error

      const csvContent = [
        ['Nome', 'Valor', 'Data', 'Categoria', 'Recorrência', 'Observações'].join(','),
        ...(expenses || []).map(expense => [
          expense.name,
          expense.amount,
          expense.date,
          expense.category?.name || 'Sem categoria',
          expense.recurrence === 'none' ? 'Única' : 
          expense.recurrence === 'weekly' ? 'Semanal' : 'Mensal',
          expense.notes || ''
        ].map(field => `"${field}"`).join(','))
      ].join('\n')

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
      const link = document.createElement('a')
      link.href = URL.createObjectURL(blob)
      link.download = `despesas_${format(new Date(), 'yyyy-MM-dd')}.csv`
      link.click()

      toast.success('Dados exportados com sucesso!')
    } catch (error) {
      toast.error('Erro ao exportar dados')
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-gray-200 rounded-xl h-32"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-gray-200 rounded-xl h-96"></div>
            <div className="bg-gray-200 rounded-xl h-96"></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Acompanhe suas despesas de {format(new Date(), 'MMMM yyyy', { locale: ptBR })}
          </p>
        </div>
        <button
          onClick={exportToCsv}
          className="mt-4 sm:mt-0 inline-flex items-center space-x-2 bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Exportar CSV</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total do Mês"
          value={formatCurrency(stats.monthlyTotal)}
          icon={DollarSign}
          color="emerald"
        />
        <StatCard
          title="Total da Semana"
          value={formatCurrency(stats.weeklyTotal)}
          icon={Calendar}
          color="blue"
        />
        <StatCard
          title="Projeção Mensal"
          value={formatCurrency(stats.monthlyProjection)}
          icon={TrendingUp}
          color="purple"
        />
        <StatCard
          title="Categorias Ativas"
          value={stats.expensesByCategory.length.toString()}
          icon={PieChart}
          color="orange"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {stats.expensesByCategory.length > 0 && (
          <ExpenseChart
            type="pie"
            data={stats.expensesByCategory}
            title="Despesas por Categoria"
          />
        )}
        {stats.dailyExpenses.length > 0 && (
          <ExpenseChart
            type="line"
            data={stats.dailyExpenses}
            title="Evolução Diária"
          />
        )}
      </div>

      {/* Recent Expenses */}
      <ExpenseList />
    </div>
  )
}