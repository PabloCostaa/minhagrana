import React, { useState, useEffect } from 'react'
import { useAuth } from '../../contexts/AuthContext'
import { supabase } from '../../lib/supabase'
import { format, parseISO } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { Edit2, Trash2, Calendar, Tag, DollarSign } from 'lucide-react'
import toast from 'react-hot-toast'

interface Expense {
  id: string
  name: string
  amount: number
  date: string
  recurrence: 'none' | 'weekly' | 'monthly'
  notes?: string
  category: {
    name: string
    color: string
  } | null
}

interface ExpenseListProps {
  refresh?: boolean
  onEdit?: (expense: Expense) => void
}

export function ExpenseList({ refresh, onEdit }: ExpenseListProps) {
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      loadExpenses()
    }
  }, [user, refresh])

  const loadExpenses = async () => {
    if (!user) return

    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('expenses')
        .select(`
          *,
          category:categories(name, color)
        `)
        .eq('user_id', user.id)
        .order('date', { ascending: false })
        .limit(50)

      if (error) throw error
      setExpenses(data || [])
    } catch (error) {
      console.error('Error loading expenses:', error)
      toast.error('Erro ao carregar despesas')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir esta despesa?')) return

    try {
      const { error } = await supabase
        .from('expenses')
        .delete()
        .eq('id', id)

      if (error) throw error

      toast.success('Despesa excluída com sucesso!')
      loadExpenses()
    } catch (error) {
      toast.error('Erro ao excluir despesa')
    }
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  const getRecurrenceLabel = (recurrence: string) => {
    const labels = {
      none: 'Única',
      weekly: 'Semanal',
      monthly: 'Mensal'
    }
    return labels[recurrence as keyof typeof labels] || 'Única'
  }

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    )
  }

  if (expenses.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center">
        <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">
          Nenhuma despesa cadastrada
        </h3>
        <p className="text-gray-600">
          Comece cadastrando sua primeira despesa para acompanhar seus gastos.
        </p>
      </div>
    )
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Despesas Recentes</h3>
      </div>
      
      <div className="divide-y divide-gray-100">
        {expenses.map((expense) => (
          <div key={expense.id} className="p-6 hover:bg-gray-50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: expense.category?.color + '20' }}
                >
                  <Tag 
                    className="w-6 h-6" 
                    style={{ color: expense.category?.color || '#10B981' }}
                  />
                </div>
                
                <div className="flex-1">
                  <h4 className="text-lg font-medium text-gray-900">
                    {expense.name}
                  </h4>
                  <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                    <div className="flex items-center space-x-1">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {format(parseISO(expense.date), 'dd/MM/yyyy', { locale: ptBR })}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Tag className="w-4 h-4" />
                      <span>{expense.category?.name || 'Sem categoria'}</span>
                    </div>
                    <span className="px-2 py-1 bg-gray-100 rounded-full text-xs">
                      {getRecurrenceLabel(expense.recurrence)}
                    </span>
                  </div>
                  {expense.notes && (
                    <p className="text-sm text-gray-600 mt-2">{expense.notes}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className="text-lg font-semibold text-gray-900">
                    {formatCurrency(expense.amount)}
                  </p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => onEdit?.(expense)}
                    className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                    title="Editar"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(expense.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    title="Excluir"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}